package ru.mirea.lab5;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

public class Program extends JFrame implements ActionListener, ItemListener {

    private Timer timer;
    private int count = 0;
    private final int max_quantity;
    private final Image[] images;
    private JToggleButton button = new JToggleButton("stop");

    public Program(String winTitle, int w, int h) {
        super(winTitle);
        String[] names = {"cat1.png", "cat2.png", "cat3.png", "cat4.png", "cat5.png", "cat6.png"};

        max_quantity = names.length;
        images = new Image[max_quantity];

        button.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                int state = e.getStateChange();
                if (state == ItemEvent.SELECTED) {
                    timer.stop();
                    button.setText("start");
                } else {
                    timer.start();
                    button.setText("stop");
                }
            }
        });

        try {
            for (int i = 0; i < max_quantity; i++) {
                images[i] = new ImageIcon("C:\\Users\\volg2\\OneDrive\\Изображения\\учеба\\"
                        + names[i]).getImage();
            }
        } catch (NullPointerException e) {
            System.out.println("Problem is: " + e);
        }

        setSize(w, h);

        JPanel canvasPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D fig = (Graphics2D) g;
                fig.drawImage(images[count], 0, 0, this);
            }
        };

        timer = new Timer(100, new ActionListener() {
            public void actionPerformed(ActionEvent ev) {
                count++;
                if (count > max_quantity - 1) {
                    count = 0;
                }
                canvasPanel.repaint();
            }
        });
        //timer.start();

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(button);

        Container content = getContentPane();
        content.add(BorderLayout.SOUTH, buttonPanel);
        content.add(BorderLayout.CENTER, canvasPanel);

    }

    @Override
    public void actionPerformed(ActionEvent e) {

    }

    @Override
    public void itemStateChanged(ItemEvent e) {

    }

    public static void main(String[] args) {
        Program anim = new Program("Cat", 900, 600);
        anim.setVisible(true);
    }
}

