package ru.mirea.lab5;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class Matches extends JFrame implements ActionListener {

    TextField text = new TextField(45);
    private JPanel buttonsPanel, scorePanel;
    private JButton button1, button2;
    private final int width, height;
    private int m, r;

    public Matches(String winTitle, int w, int h) {
        super(winTitle);
        width = w;
        height = h;
        setSize(width, height);
        buttonsPanel = new JPanel();
        scorePanel = new JPanel();
        button1 = new JButton("AC Milan");
        button2 = new JButton("Real Madrid");
        button1.setActionCommand("addm");
        button2.setActionCommand("addr");
        button1.addActionListener(this);
        button2.addActionListener(this);
        buttonsPanel.add(button1);
        buttonsPanel.add(button2);
        scorePanel.add(text);
        add(BorderLayout.NORTH, buttonsPanel);
        add(BorderLayout.CENTER, scorePanel);
        getContentPane();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String temp, winner;
        String command = e.getActionCommand();
        if (command.equals("addr")) {
            r++;
            temp = "Real Madrid";
        } else {
            m++;
            temp = "AC Milan";
        }
        if (r > m) {
            winner = "Real Madrid";
        } else if (r == m) {
            winner = "Draw";
        } else {
            winner = "AC Milan";
        }
        text.setText("Result: " + m + " X " + r + "\tLast Scorer: " + temp + "\tWinner: " + winner);
    }

    public static void main(String[] args) {
        JFrame wind = new Matches("Match", 500, 120);
        wind.setVisible(true);
    }
}





