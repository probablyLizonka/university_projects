package ru.mirea.lab1;

import java.util.Scanner; //импортируем класс

public class example {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n, summa = 0;
        System.out.print("Введите количество чисел в массиве: ");
        if (sc.hasNextInt()) {
            n = sc.nextInt();
            int[] array = new int[n];
            System.out.print("Введите массив: ");
            for (int i = 0; i < n; i++) {
                array[i] = sc.nextInt();
                summa += array[i];
            }
            double average = (double) summa / n;
            System.out.println("Сумма: " + summa);
            System.out.println("Среднее арифметическое: " + average);
        } else {
            System.out.println("Вы ввели не целое положительное число");
        }


        System.out.print("Введите количество чисел в массиве: ");
        if (sc.hasNextInt()) {
            n = sc.nextInt();
            int j = 0, maxel = -10000, minel = 10000;
            int[] array = new int[n];
            System.out.print("Введите массив: ");
            while (n != 0) {
                array[j] = sc.nextInt();
                if (maxel < array[j]){
                    maxel = array[j];
                }
                if (minel > array[j]){
                    minel = array[j];
                }
                    j++;
                n -= 1;
            }
            System.out.println("Минимальный элемент: " + minel);
            System.out.println("Максимальный элемент: " + maxel);
        } else {
            System.out.println("Вы ввели не целое положительное число");
        }

        float x;
        for (int i = 1; i < 11; i++) {
            x = (float)1/i;
            System.out.printf("%10.2f", x);
        }

    }
}
