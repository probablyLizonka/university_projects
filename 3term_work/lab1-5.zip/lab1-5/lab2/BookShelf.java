package ru.mirea.lab2;

import java.util.*;

public class BookShelf {
    private Book[] book;
    private int count;

    public BookShelf(Book[] book) {
        this.book = book;
    }

    public Book[] getBook() {
        return book;
    }

    public void setBook(Book[] book) {
        this.book = book;
    }

    public void FindCount() {
        count = book.length;
    }

    @Override
    public String toString() {
        return "BookShelf{" +
                "book=" + Arrays.toString(book) +
                ", count=" + count +
                '}';
    }

    public Book[] FindBook() {
        FindCount();
        int minyear = book[0].getYear();
        int maxyear = book[0].getYear();
        Book[] mint = new Book[2];
        mint[0] = book[0];
        mint[1] = book[0];
        for (int i = 0; i < count; i++) {

            if (minyear > book[i].getYear()) {
                minyear = book[i].getYear();
                mint[0] = book[i];
            }
            if (maxyear < book[i].getYear()) {
                maxyear = book[i].getYear();
                mint[1] = book[i];
            }
        }


        return mint;
    }


}
