package ru.mirea.lab2;

import java.util.Scanner;

public class TestAuthor {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Author a1 = new Author("Lisa", "elizaveta.suprunova@mail.ru", 'f');
        System.out.println("Данные об авторе:");
        System.out.println(a1);
        a1.setName("hiiii");
        System.out.println(a1);

    }
}
