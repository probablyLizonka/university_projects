package ru.mirea.lab2;

public class StringMassive {
    public static void main(String[] args) {
        String[] fraze = {"Всем ", "привет ", ", ", "меня ", "зовут ", "Лиза ", "! "};

        for (String s : fraze) {
            System.out.print(s);
        }

        String temp;
        for (int i = 0; i < fraze.length/2; i++){
            temp = fraze[i];
            fraze[i] = fraze[fraze.length - i - 1];
            fraze[fraze.length - i - 1] = temp;

        }

        System.out.println();
        for (String s : fraze) {
            System.out.print(s);
        }

    }
}
