package ru.mirea.lab2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class BookTset {
    public static void main(String[] args) {
        List<Book> books = new ArrayList<>();

        Book b1 = new Book("Автор1", "Первая", 2001);
        Book b2 = new Book("Автор2", "Вторая", 2002);
        Book b3 = new Book("Автор3", "Третья", 2003);


        books.add(b2);
        books.add(b3);
        books.add(b1);


        Book[] book = new Book[3];
        book[0] = b1;
        book[1] = b2;
        book[2] = b3;


        BookShelf d = new BookShelf(book);
        Book[] v = d.FindBook();
        for (int i = 0; i < 2; i++) {
            System.out.println(v[i]);
        }


        Collections.sort(books);
        System.out.println(books);


    }
}
