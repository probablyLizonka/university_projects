package ru.mirea.lab4_1;

public class Person {
    private String fullname;
    private int age;

    public Person(int age, String fullname) {
        this.age = age;
        this.fullname = fullname;
    }

    public Person() {
    }

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    @Override
    public String toString() {
        return "Person{" +
                "fullname='" + fullname + '\'' +
                ", age=" + age +
                '}';
    }

    public void move() {
        System.out.println("Человечек " + fullname + " двигается");
    }

    public void talk() {
        System.out.println("Человечек " + fullname + " говорит");
    }

    public static void main(String[] args) {
        Person p1 = new Person();
        p1.fullname = "Лиза";
        p1.age = 19;

        Person p2 = new Person(19, "Маша");

        p1.talk();
        p2.move();
    }
}
