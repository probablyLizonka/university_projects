package ru.mirea.lab3;

import java.lang.Float;

public class exer2 {
    public static void main(String[] args) {

        String s1 = "100.01";
        int i2 = 89;

        double d1 = Double.valueOf(s1);
        double d2 = Double.valueOf(i2);

        //Float j = new Float(34.9);

        double d3 = Double.parseDouble(s1);

        System.out.println(d1);
        System.out.println(d2);
        System.out.println(d3);
    }
}
