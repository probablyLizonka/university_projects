package ru.mirea.lab3;

import java.text.NumberFormat;
import java.util.*;

public class Report {
    public static void generateReport(Employee[] employee_array){
        Locale.setDefault(Locale.US);
        NumberFormat n = NumberFormat.getCurrencyInstance();

        for (Employee employee : employee_array) {
            String temp = n.format(employee.getSalary());
            System.out.println("Зарплата работника " + employee.getFullname() + " " + temp);
        }
    }
}
