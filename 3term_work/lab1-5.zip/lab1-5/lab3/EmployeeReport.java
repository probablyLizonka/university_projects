package ru.mirea.lab3;

public class EmployeeReport {
    public static void main(String[] args) {
        Employee e1 = new Employee("Супрунова", 100.0);
        Employee e2 = new Employee("Комлева", 89.4343);
        Employee e3 = new Employee("Юрочкин", 99.101);
        Employee e4 = new Employee("Орехов", 10.0111);
        Employee e5 = new Employee("Попов", 77.677);

        Employee[] all_salaries = new Employee[5];
        all_salaries[0] = e1;
        all_salaries[1] = e2;
        all_salaries[2] = e3;
        all_salaries[3] = e4;
        all_salaries[4] = e5;


        for (Employee allSalary : all_salaries) {
            System.out.println(allSalary);
        }

        Report.generateReport(all_salaries);

    }
}
