package ru.mirea.lab3;

import java.util.*;

public class exer1 {
    public static void main(String[] args) {
        // через класс Random
        Random rand = new Random();

        double[] mas1 = new double[5];
        for (int i = 0; i < mas1.length; i++) {
            mas1[i] = rand.nextDouble();
        }
        System.out.println("Массив из рандомных чисел:");
        for (double j : mas1) {
            System.out.print(j + " ");
        }
        System.out.println();
        Arrays.sort(mas1);
        System.out.println("Отсортированный массив:");
        for (double j : mas1) {
            System.out.print(j + " ");
        }

        // с помощью метода random() класса Math
        System.out.println();
        System.out.println("Массив из рандомных чисел:");
        double[] mas2 = new double[5];
        for (int i = 0; i < mas2.length; i++) {
            mas2[i] = Math.random();
        }
        for (double j : mas2) {
            System.out.print(j + " ");
        }
        System.out.println();
        Arrays.sort(mas2);
        System.out.println("Отсортированный массив:");
        for (double j : mas2) {
            System.out.print(j + " ");
        }
        System.out.println();


        // Задание 3

        System.out.println("Задание 3");
        int[] mass = new int[4];
        System.out.println("Массив из чисел на отрезке [10, 99]:");
        for (int i = 0; i < mass.length; i++) {
            mass[i] = rand.nextInt(10, 100);
            System.out.print(mass[i] + " ");
        }
        System.out.println();
        for (int i = 0; i < mass.length - 1; i++) {
            if (mass[i] >= mass[i + 1]) {
                System.out.println("Массив не является строго возрастающей последовательностью");
                break;
            }
            if (i == mass.length - 2){
                System.out.println("Массив является строго возрастающей последовательностью");
            }
        }
        System.out.println();
    }
}
