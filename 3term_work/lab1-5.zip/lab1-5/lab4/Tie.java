package ru.mirea.lab4;

public class Tie extends Clothes implements MenClothig {
    public Tie(Size size, double price, String color) {
        super(size, price, color);
    }


    @Override
    public void dressMan(Clothes[] ar) {

    }

    @Override
    public String toString() {
        return "Tie{" + super.toString() + '}';
    }
}
