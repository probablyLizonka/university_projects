package ru.mirea.lab4;

public class Atelier implements MenClothig, WomenClothing {

    public void dressMan(Clothes[] arr) {
        for (int i = 0; i < arr.length - 1; i++) {
            System.out.println(arr[i]);
        }
    }


    public void dressWomen(Clothes[] arr) {
        for (int i = 0; i < arr.length; i++) {
            if (i == 2) {
                continue;
            }
            System.out.println(arr[i]);
        }
    }

    public static void main(String[] args) {
        TShirt shirt = new TShirt(Size.XS, 100.0, "red");
        Pants pants = new Pants(Size.L, 9, "green");
        Tie tie = new Tie(Size.XS, 89, "blue");
        Skirt skirt = new Skirt(Size.L, 90, "white");

        System.out.println("Вся одежда:");
        Clothes[] clothes = new Clothes[4];
        clothes[0] = shirt;
        clothes[1] = pants;
        clothes[2] = tie;
        clothes[3] = skirt;

        for (Clothes thing : clothes) {
            System.out.println(thing);
        }

        Atelier at = new Atelier();
        System.out.println("Одежда для мужчин");
        at.dressMan(clothes);
        System.out.println("Одежда для женщин");
        at.dressWomen(clothes);

    }
}
