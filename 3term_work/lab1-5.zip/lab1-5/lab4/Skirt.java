package ru.mirea.lab4;

public class Skirt extends Clothes implements WomenClothing {
    public Skirt(Size size, double price, String color) {
        super(size, price, color);
    }

    @Override
    public void dressWomen(Clothes[] ar) {

    }
    @Override
    public String toString() {
        return "Skirt{" + super.toString() + '}';
    }
}
