package ru.mirea.lab4;

public class Pants extends Clothes implements MenClothig, WomenClothing {
    public Pants(Size size, double price, String color) {
        super(size, price, color);
    }

    @Override
    public void dressMan(Clothes[] ar) {

    }

    @Override
    public void dressWomen(Clothes[] ar) {


    }
    @Override
    public String toString() {
        return "Pants{" + super.toString() + '}';
    }
}
