package ru.mirea.lab4;

public class TShirt extends Clothes implements MenClothig, WomenClothing {
    public TShirt(Size size, double price, String color) {
        super(size, price, color);
    }

    @Override
    public void dressMan(Clothes[] ar) {
        System.out.println("v");
    }

    @Override
    public void dressWomen(Clothes[] ar) {

    }

    @Override
    public String toString() {
        return "TShirt{" + super.toString() + '}';
    }
}
