package ru.mirea.lab1;

import java.lang.*;
import java.util.Scanner;

public class Tester {
    public static void main(String[] args) {
        double r;
        Work2 k1 = new Work2(3.1, 4.1, 5.1, "red");
        System.out.println(k1);
        System.out.println("\nДлина окружности = " + k1.getLength() + "см");
        Scanner source = new Scanner(System.in);
        System.out.println("Введите радиус ");
        r = source.nextDouble();
        k1.setR(r);
        System.out.println("\nДлина окружности = " + k1.getLength() + "см");
    }
}

