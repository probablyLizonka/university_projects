package ru.mirea.lab28;

import ru.mirea.lab13.Person;
import ru.mirea.lab23.ArrayQueue;

import java.util.HashSet;
import java.util.TreeSet;

public class Convert {
    public static <E> TreeSet<E> convertation(HashSet<E> h) throws ClassCastException {
        return new TreeSet<>(h);
    }

    public static void main(String[] args) {
        HashSet<Person> hashSet = new HashSet<>();
        hashSet.add(new Person(new StringBuilder("Супрунова")));
        hashSet.add(new Person(new StringBuilder("Юрочкин")));
        hashSet.add(new Person(new StringBuilder("Комлева")));
        hashSet.add(new Person(new StringBuilder("Орехов")));
        System.out.println("HashSet of peoples: " + hashSet);
        HashSet<Integer> hashSet1 = new HashSet<>();
        for (int i = 0; i < 10; i++) {
            hashSet1.add(i);
        }
        System.out.println("HashSet of integers: " + hashSet1);
        try {
            TreeSet<Person> treeSet = convertation(hashSet);
            System.out.println("TreeSet of peoples: " + treeSet);
        } catch (ClassCastException e) {
            System.out.println("Определите Comparable для класса " +
                    hashSet.iterator().next().getClass().getSimpleName());
        }
        try {
            TreeSet<Integer> treeSet1 = convertation(hashSet1);
            System.out.println("TreeSet of integers: " + treeSet1);
        } catch (ClassCastException e) {
            System.out.println("Определите Comparable для класса " +
                    hashSet.iterator().next().getClass().getSimpleName());
        }
    }
}
