package ru.mirea.lab28;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MyMap {
    public HashMap<String, String> createMap() {
        HashMap<String, String> nameMap = new HashMap<>();
        String[] lastNames = {"Супрунова", "Юрочкин", "Комлева", "Орехов"};
        String[] firstNames = {"Елизавета", "Максим", "Мария", "Максим"};
        for (int i = 0; i < lastNames.length; i++) {
            nameMap.put(lastNames[i], firstNames[i]);
        }
        return nameMap;
    }

    public StringBuilder getSameFirstNameCount() {
        int c = 0;
        HashMap<String, String> hashMap = createMap();
        ArrayList<String> values = new ArrayList<>(hashMap.values());
        HashMap<String, Integer> repetitions = new HashMap<>();
        for (String item : values) {
            if (repetitions.containsKey(item))
                repetitions.put(item, repetitions.get(item) + 1);
            else
                repetitions.put(item, 1);
        }
        StringBuilder sb = new StringBuilder();

        int overAllCount = 0;

        for (Map.Entry<String, Integer> e : repetitions.entrySet()) {
            if (e.getValue() > 1) {
                overAllCount += 1;

                sb.append("\n");
                sb.append(e.getKey());
                sb.append(": ");
                sb.append(e.getValue());
                sb.append(" раза");
            }
        }

        if (overAllCount == 0) {
            sb.insert(0, "0 повторений");
        }

        if (overAllCount > 0) {
            sb.insert(0, " повторений имён:");
            sb.insert(0, overAllCount);
            sb.insert(0, "Всего ");
        }
        return sb;
    }

    public StringBuilder getSameLastNameCount() {
        int c = 0;
        HashMap<String, String> hashMap = createMap();
        ArrayList<String> keys = new ArrayList<>(hashMap.keySet());
        HashMap<String, Integer> repetitions = new HashMap<>();
        for (String item : keys) {
            if (repetitions.containsKey(item))
                repetitions.put(item, repetitions.get(item) + 1);
            else
                repetitions.put(item, 1);
        }
        StringBuilder sb = new StringBuilder();

        int overAllCount = 0;

        for (Map.Entry<String, Integer> e : repetitions.entrySet()) {
            if (e.getValue() > 1) {
                overAllCount += 1;

                sb.append("\n");
                sb.append(e.getKey());
                sb.append(": ");
                sb.append(e.getValue());
                sb.append(" раза");
            }
        }

        if (overAllCount == 0) {
            sb.insert(0, "0 повторений");
        }

        if (overAllCount > 0) {
            sb.insert(0, " повторений фамилий:");
            sb.insert(0, overAllCount);
            sb.insert(0, "Всего ");
        }
        return sb;
    }

    public static void main(String[] args) {
        MyMap myMap = new MyMap();
        System.out.println("Одинаковые имена: \n" + myMap.getSameFirstNameCount());
        System.out.println("Одинаковые фамилии: \n" + myMap.getSameLastNameCount());
    }
}
