package ru.mirea.lab6;

import static java.lang.Math.round;

import java.util.*;

interface Convertable {
    int convert(char type);
}

class Value implements Convertable {
    private int c;
    private char type;

    public Value(int c, char type) {
        this.c = c;
        this.type = type;
    }

    @Override
    public int convert(char needType) {
        if (type == needType) {
            return c;
        } else switch (needType) {
            case 'f':
                switch (type) {
                    case 'k':
                        c = (int) round(c * 1.8 - 459.67);
                        type = 'f';
                        return c;
                    case 'c':
                        c = (int) round(c * 1.8 + 32);
                        type = 'f';
                        return c;
                }
            case 'k':
                switch (type) {
                    case 'f':
                        c = (int) round((c + 459.67) / 1.8);
                        type = 'k';
                        return c;
                    case 'c':
                        c = (int) round(c + 273.15);
                        type = 'k';
                        return c;
                }
            case 'c':
                switch (type) {
                    case 'f':
                        c = (int) round((c - 32) / 1.8);
                        type = 'c';
                        return c;
                    case 'k':
                        c = (int) round(c - 273.15);
                        type = 'c';
                        return c;
                }
        }
        return 0;
    }
}


public class TempConvert {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Введите целое число:");
        int num;
        if (sc.hasNextInt()) {
            num = sc.nextInt();
            String typee;
            System.out.println("Введите шкалу измерения, где" +
                    "\nКельвин (K) - k" +
                    "\nФаренгейт (°F) - f" +
                    "\nЦельсий (°C) - c");

            if (sc.hasNext()) {
                typee = sc.next();
                String needType = sc.next();
                if (typee.length() == 1 && needType.length() == 1) {
                    if (needType.charAt(0) == 'f' || needType.charAt(0) == 'k' || needType.charAt(0) == 'c') {
                        if (typee.charAt(0) != needType.charAt(0)) {
                            int numm = num;
                            String v = "";
                            if (needType.charAt(0) == 'c') {
                                v = "°C";
                                System.out.println(v);
                            }
                            if (needType.charAt(0) == 'f') {
                                v = "°F";
                            }
                            if (needType.charAt(0) == 'k') {
                                v = "K";
                            }
                            switch (typee.charAt(0)) {
                                case 'f':
                                    Value numf = new Value(num, 'f');
                                    System.out.println(numm + "°F = " + numf.convert(needType.charAt(0)) + v);
                                    return;
                                case 'k':
                                    Value numk = new Value(num, 'k');
                                    System.out.println(numm + "K = " + numk.convert(needType.charAt(0)) + v);
                                    return;
                                case 'c':
                                    Value numc = new Value(num, 'c');
                                    System.out.println(numm + "°C = " + numc.convert(needType.charAt(0)) + v);
                                    return;
                                default:
                                    System.out.println("Вы ввели неверную шкалу измерения");
                            }
                        } else {
                            System.out.println("Температура не требует преобразования (указен тот же тип шкалы)");
                        }
                    } else {
                        System.out.println("Вы ввели неверную шкалу измерения (для перевода)");
                    }
                } else {
                    System.out.println("Вы ввели больше одного знака");
                }
            }
        } else {
            System.out.println("Вы ввели не целое число");
        }
        sc.close();
    }
}
