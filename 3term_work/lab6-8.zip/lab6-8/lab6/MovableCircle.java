package ru.mirea.lab6;

public class MovableCircle implements Movable {
    private int radius;
    private MovablePoint center;

    public MovableCircle(MovablePoint center, int radius) {
        this.center = center;
        this.radius = radius;
    }

    @Override
    public void moveDown(String s) {
        System.out.println("Круг движется вниз");
    }

    @Override
    public void moveLeft() {
        System.out.println("Круг движется влево");
    }

    @Override
    public void moveRight() {
        System.out.println("Круг движется вправо");
    }

    @Override
    public void moveUp(String s) {
        System.out.println("Круг движется вверх");
    }
}
