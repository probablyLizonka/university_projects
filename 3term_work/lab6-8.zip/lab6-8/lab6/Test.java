package ru.mirea.lab6;

public class Test {
    public static void main(String[] args) {
        MovablePoint point = new MovablePoint(1, 1, 16, 13);
        MovablePoint point1 = new MovablePoint(2, 2, 16, 13);
        MovableCircle circle = new MovableCircle(point, 3);
        MovableRectangle rectangle = new MovableRectangle(point1, point);

        rectangle.Speed();
        point.moveDown(point.toString());
        point1.moveUp(point1.toString());
        circle.moveRight();
        rectangle.moveLeft();
    }
}
