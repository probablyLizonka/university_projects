package ru.mirea.lab6;

public class MovablePoint implements Movable {
    int x;
    int y;
    int xSpeed;
    int ySpeed;

    public MovablePoint(int x, int y, int xSpeed, int ySpeed) {
        this.x = x;
        this.xSpeed = xSpeed;
        this.y = y;
        this.ySpeed = ySpeed;
    }

    @Override
    public String toString() {
        return "x=" + x + ", y=" + y;
    }

    @Override
    public void moveDown(String s) {
        System.out.println("Точка (" + s + ") движется вниз");
    }

    @Override
    public void moveLeft() {
        System.out.println("Точка движется влево");
    }

    @Override
    public void moveRight() {
        System.out.println("Точка движется вправо");
    }

    @Override
    public void moveUp(String s) {
        System.out.println("Точка (" + s + ") движется вверх");
    }
}
