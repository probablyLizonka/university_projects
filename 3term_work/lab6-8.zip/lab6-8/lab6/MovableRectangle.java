package ru.mirea.lab6;

public class MovableRectangle implements Movable {
    private MovablePoint topLeft;
    private MovablePoint bottomRight;

    public MovableRectangle(MovablePoint bottomRight, MovablePoint topLeft) {
        this.bottomRight = bottomRight;
        this.topLeft = topLeft;
    }

    public void Speed() {
        if (topLeft.xSpeed != bottomRight.xSpeed) {
            System.out.println("Скорость не совпадает");
        } else if (topLeft.ySpeed != bottomRight.ySpeed) {
            System.out.println("Скорость не совпадает");
        }
    }

    @Override
    public void moveDown(String s) {
        System.out.println("Прямоугольник движется вниз");
    }

    @Override
    public void moveLeft() {
        System.out.println("Прямоугольник движется влево");
    }

    @Override
    public void moveRight() {
        System.out.println("Прямоугольник движется вправо");
    }

    @Override
    public void moveUp(String s) {
        System.out.println("Прямоугольник движется вверх");
    }
}
