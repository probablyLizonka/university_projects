package ru.mirea.lab6;

public interface Movable {
    void moveUp(String s);

    void moveDown(String s);

    void moveLeft();

    void moveRight();

}
