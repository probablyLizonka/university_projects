package ru.mirea.lab7;

public interface WorkWithString {
    int countDigits();

    String oddNum();

    String invert();
}
