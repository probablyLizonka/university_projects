package ru.mirea.lab7;

public class ProcessStrings implements WorkWithString {
    private String s;

    public ProcessStrings(String s) {
        this.s = s;
    }

    @Override
    public int countDigits() {
        int digits = 0;
        for (int i = 0; i < s.length(); i++) {
            if (s.charAt(i) == ' ') {
                digits++;
            }
        }
        return s.length() - digits;
    }

    @Override
    public String invert() {
        return new StringBuilder(s).reverse().toString();
    }

    @Override
    public String oddNum() {
        StringBuilder newS = new StringBuilder();
        for (int i = 0; i < s.length(); i += 2) {
            newS.append(s.charAt(i));
        }
        return newS.toString();
    }
}
