package ru.mirea.lab7;

import java.lang.Math;

public interface MathCalculable {
    double PI = Math.PI;

    static int power(int num, int power) {
        return (int) Math.pow(num, power);
    }

    int absComplex();

}
