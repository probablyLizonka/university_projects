package ru.mirea.lab7;

import java.util.*;

public class Test {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String ss;
        System.out.println("Введите строку:");
        ss = sc.nextLine();
        ProcessStrings s = new ProcessStrings(ss);
        System.out.println("Количесво символов (пробелы не считаются): " + s.countDigits());
        System.out.println("НЕчетные символы строки c пробелами: " + s.oddNum());
        System.out.println("Перевёрнутая строка: " + s.invert());

        System.out.println("----------");

        System.out.println("Возведение в степень через статический метод интерфейса: " +
                MathCalculable.power(3, 2));
        MathFunc m1 = new MathFunc(3);
        MathFunc m2 = new MathFunc(3, 4);
        System.out.println("Длина окружности с радиусом " + m1.getRadius() + " : " + m1.lenCir());
        System.out.println("Модуль комплексного числа " + m2 + " : " + m2.absComplex());
    }
}
