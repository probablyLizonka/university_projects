package ru.mirea.lab7;

import java.lang.Math;

public class MathFunc implements MathCalculable {
    private int radius;
    private int re, im;

    public MathFunc(int radius) {
        this.radius = radius;
    }

    public MathFunc(int re, int im) {
        this.re = re;
        this.im = im;
    }

    @Override
    public String toString() {
        return im + " + " + re + "i";
    }

    public int getRadius() {
        return radius;
    }

    @Override
    public int absComplex() {
        return (int) Math.pow(Math.pow(re, 2) + Math.pow(im, 2), 0.5);
    }

    public double lenCir() {
        return 2 * MathCalculable.PI * radius;
    }
}
