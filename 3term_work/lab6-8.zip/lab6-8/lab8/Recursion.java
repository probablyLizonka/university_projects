package ru.mirea.lab8;

import java.util.*;

public class Recursion {
    static Scanner sc = new Scanner(System.in);

    public static String line(int n) {
        if (n == 1) {
            return "1";
        }
        return line(n - 1) + " " + n;
    }

    public static int maxLine() {
        try {
            int num = sc.nextInt();

            if (num == 0) {
                return 0;
            } else {
                return Math.max(num, maxLine());
            }
        } catch (InputMismatchException e) {
            System.out.println("Программа не сработала. Вы ввели не число");
        }
        return 0;
    }

    public static String reverseN(int N) {
        if (N < 10) {
            return Integer.toString(N);
        } else {
            return N % 10 + reverseN(N / 10);
        }
    }

    public static int countMax(int max, int c) {
        try {
            int num = sc.nextInt();

            if (num > 0) {
                if (num > max) {
                    return countMax(num, 1);
                }
                if (num == max) {
                    return countMax(num, c + 1);
                } else {
                    return countMax(max, c);
                }
            } else {
                System.out.println("Количество максимумов в последовательности: " + c);
            }
        } catch (InputMismatchException e) {
            System.out.println("Программа не сработала. Вы ввели не число");
        }
        return 0;
    }

    public static void main(String[] args) {
        System.out.println("Задание 2: числа от 1 для n");
        System.out.println("Введите натуральное число n");
        String n = sc.nextLine();
        while (!Character.isDigit(n.charAt(0))) {
            System.out.println("Введите n заново");
            n = sc.nextLine();
        }
        System.out.println(line(Integer.parseInt(n)));

        System.out.println("Задание 17");
        System.out.println("Введите целочисленную последовательность, где 0 - конец последовательности");
        System.out.println("Максимум последовательности: " + maxLine());

        System.out.println("Задание 15");
        System.out.println("Введите  целое число n");
        String n1 = sc.next();
        while (!Character.isDigit(n1.charAt(0))) {
            System.out.println("Введите n заново");
            n1 = sc.next();
        }
        System.out.println("Число наоборот: " + reverseN(Integer.parseInt(n1)));

        System.out.println("Задание 16");
        System.out.println("Введите целочисленную последовательность, где 0 - конец последовательности");
        countMax(0, 1);
    }
}
