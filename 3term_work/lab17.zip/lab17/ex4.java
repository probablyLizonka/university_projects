package ru.mirea.lab17;

import java.util.Comparator;
import java.util.Scanner;

public class ex4 {
    Scanner sc = new Scanner(System.in);
    MyDoubleLinkedListForStrings strings = new MyDoubleLinkedListForStrings();

    public void addString() {
        System.out.println("Введите строку");
        String s = new String(sc.nextLine());
        strings.add(s);
        System.out.println("Строка добавлена в список");
    }

    public void printStringsForward() {
        System.out.println("Все строки в прямом порядке:");
        strings.getNext();
    }

    public void printStringsBackward() {
        System.out.println("Все строки в обратном порядке:");
        strings.getPrev();
    }

    public ex4() {
        boolean running = true;
        System.out.println("C помощью Double Linked List:");
        System.out.println("\tРабота со строками");
        while (running) {
            System.out.println("""
                    
                    Выберите действие:\
                    
                    1. Ввести строку\
                    
                    2. Вывести список строк в прямом порядке\
                    
                    3. Вывести строки в обратном порядке\
                    
                    4. Выйти из программы
                    """);
            String choice = sc.nextLine();
            switch (choice) {
                case "1" -> addString();
                case "2" -> printStringsForward();
                case "3" -> printStringsBackward();
                case "4" -> running = false;
                default -> System.out.println("Ошибка ввода. Введите снова");
            }
        }
    }

    public static void main(String[] args) {
        new ex4();
    }
}

class Node1ForStrings {
    private String data;
    private Node1ForStrings next;
    private Node1ForStrings prev;

    public Node1ForStrings(String dataValue) {
        next = null;
        prev = null;
        data = dataValue;
    }

    public String getData() {
        return data;
    }

    public void setData(String dataValue) {
        data = dataValue;
    }

    public Node1ForStrings getNext() {
        return next;
    }

    public void setNext(Node1ForStrings nextValue) {
        next = nextValue;
    }

    public Node1ForStrings getPrev() {
        return prev;
    }

    public void setPrev(Node1ForStrings prev) {
        this.prev = prev;
    }

    @Override
    public String toString() {
        return data;
    }
}


class MyDoubleLinkedListForStrings {
    private Node1ForStrings head;
    private Node1ForStrings tail;
    private int listCount;

    public MyDoubleLinkedListForStrings() {
        head = new Node1ForStrings(null);
        tail = new Node1ForStrings(null);
        listCount = 0;
    }

    public void add(String data) {
        listCount++;
        if (head.getData() == null) {
            head.setData(data);
            tail.setData(data);
            return;
        }
        if (size() == 2) {
            Node1ForStrings newNode = new Node1ForStrings(data);
            if (new StringComparator().compare(head.getData(), newNode.getData()) <= 0) {
                tail = newNode;
                tail.setPrev(head);
                head.setNext(tail);
            } else {
                Node1ForStrings temp = new Node1ForStrings(data);
                temp.setNext(head);
                head.setPrev(temp);
                head = temp;
                tail = head.getNext();
            }
            return;
        }
        Node1ForStrings temp = head;
        Node1ForStrings newNode = new Node1ForStrings(data);
        for (int i = 0; i < size() - 1; i++) {
            if (new StringComparator().compare(temp.getData(), newNode.getData()) > 0) {
                newNode.setNext(temp);
                if (temp == head) {
                    head.setPrev(newNode);
                    head = newNode;
                    return;
                }
                newNode.setPrev(temp.getPrev());
                temp.getPrev().setNext(newNode);
                temp.setPrev(newNode);
                return;
            }
            temp = temp.getNext();
        }
        tail.setNext(newNode);
        newNode.setPrev(tail);
        tail = tail.getNext();
    }


    public void getNext() {
        Node1ForStrings temp = head;
        int i = 0;
        while (temp != null) {
            i++;
            System.out.println(i + ". " + temp.getData());
            temp = temp.getNext();
        }
    }

    public void getPrev() {
        Node1ForStrings temp = tail;
        int i = 0;
        while (temp != null) {
            i++;
            System.out.println(i + ". " + temp.getData());
            temp = temp.getPrev();
        }

    }

    public int size() {
        return listCount;
    }
}

class StringComparator implements Comparator<String> {
    @Override
    public int compare(String o1, String o2) {
        return o1.compareTo(o2);
    }
}