package ru.mirea.lab17;

import java.util.Arrays;
import java.util.InputMismatchException;
import java.util.Scanner;

public class ex5 {
    Scanner sc = new Scanner(System.in);
    MyLinkedListForInt values = new MyLinkedListForInt();

    public void addValue() {
        try {
            System.out.println("Введите значение");
            int data = sc.nextInt();
            sc.nextLine();
            values.add(data);
            System.out.println("Значение введено");
        } catch (InputMismatchException e) {
            System.out.println("Неверный ввод.");
            sc.nextLine();
        }
    }

    public void printValues() {
        System.out.println("Список значений");
        for (int i = 0; i < values.size(); i++) {
            System.out.println(Arrays.toString(values.get(i)));
        }
    }

    public ex5() {
        boolean running = true;
        System.out.println("C помощью Linked List:");
        System.out.println("\tРабота с массивами");
        while (running) {
            System.out.println("""
                    
                    Выберите действие:\
                    
                    1. Ввести значение\
                    
                    2. Вывести список значений\
                    
                    3. Выйти из программы
                    """);
            String choice = sc.nextLine();
            switch (choice) {
                case "1" -> addValue();
                case "2" -> printValues();
                case "3" -> running = false;
                default -> System.out.println("Ошибка ввода. Введите снова");
            }
        }
    }

    public static void main(String[] args) {
        new ex5();
    }
}

class MyLinkedListForInt {
    private NodeForInt head;
    private int listCount;

    static class NodeForInt {
        private int[] data = new int[5];
        private NodeForInt next;
        private int counter = 0;
        private int[] copyData = new int[5];

        public NodeForInt() {
            next = null;
        }

        public int[] getData() {
            return copyData;
        }

        public void setData(int dataValue) {
            counter++;
            data[counter - 1] = dataValue;
            copyData = Arrays.copyOf(data, 5);
        }

        public void sort() {
            boolean isSorted = false;
            while (!isSorted) {
                isSorted = true;
                for (int i = 0; i < 4; i++) {
                    if (copyData[i] > copyData[i + 1]) {
                        int temp = copyData[i];
                        copyData[i] = copyData[i + 1];
                        copyData[i + 1] = temp;
                        isSorted = false;
                    }
                }
            }
        }

        public NodeForInt getNext() {
            return next;
        }

        public void setNext(NodeForInt nextValue) {
            next = nextValue;
        }

        @Override
        public String toString() {
            return Arrays.toString(data);
        }
    }


    public MyLinkedListForInt() {
        head = new NodeForInt();
        listCount = 0;
    }

    public void add(int data) {
        if (size() == 0) {
            head.setData(data);
            listCount++;
            return;
        }
        NodeForInt current = head;
        if (current.counter < 5) {
            current.setData(data);
            return;
        }
        while (current.getNext() != null) {
            current = current.getNext();
            if (current.counter < 5) {
                current.setData(data);
                return;
            }
        }
        NodeForInt tmp = new NodeForInt();
        current.setNext(tmp);
        tmp.setData(data);
        listCount++;
    }

    public int[] get(int index) {
        if (index < 0) {
            return null;
        }
        if (index == 0) {
            head.sort();
            return head.getData();
        }
        NodeForInt current = head.getNext();
        for (int i = 1; i < index; i++) {
            if (current.getNext() == null) {
                return null;
            }
            current = current.getNext();
        }
        current.sort();
        return current.getData();
    }

    public int size() {
        return listCount;
    }
}