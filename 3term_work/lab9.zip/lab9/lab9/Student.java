package ru.mirea.lab9;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;

public class Student implements Comparable<Student> {
    private String name;
    private String surname;
    private String group;
    private int id;
    private final Calendar birthDate;
    private int year;
    private int month;
    private int date;

    public Student(String group, int id, String name, String surname, int year, int month, int date) {
        this.group = group;
        this.id = id;
        this.name = name;
        this.surname = surname;
        this.year = year;
        this.month = month;
        this.date = date;
        this.birthDate = Calendar.getInstance();
        birthDate.set(year, month - 1, date);
    }

    public int getDate() {
        return date;
    }

    public void setDate(int date) {
        this.date = date;
    }

    public int getMonth() {
        return month;
    }

    public void setMonth(int month) {
        this.month = month;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getId() {
        return id;
    }

    public String getGroup() {
        return group;
    }

    public void setGroup(String group) {
        this.group = group;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String dataFormatter(Date data) {
        SimpleDateFormat dateFormatter = new SimpleDateFormat("d MMMM yyyy");
        return dateFormatter.format(data);
    }

    @Override
    public String toString() {
        return "Student{" +
                "id=" + id + '\'' +
                "group='" + group + '\'' +
                ", name='" + name + '\'' +
                ", surname='" + surname + '\'' +
                ", birthDate='" + dataFormatter(birthDate.getTime()) + '\'' +
                '}' + "\n";
    }


    @Override
    public int compareTo(Student o) {
        return (this.id - o.id);
    }

    // сортировка вставками
    public static void InsertionSort(Student[] a) {
        int N = a.length;

        for (int i = 1; i < N; i++) {
            for (int j = i; j > 0 && ((a[j].compareTo(a[j - 1])) < 0); j--) {
                Student temp = a[j];
                a[j] = a[j - 1];
                a[j - 1] = temp;
            }
        }
    }

    // сортировка слиянием
    public static Student[] mergeSort(Student[] sortArr) {
        Student[] buffer1 = Arrays.copyOf(sortArr, sortArr.length);
        Student[] buffer2 = new Student[sortArr.length];
        return mergeSortInner(buffer1, buffer2, 0, sortArr.length);
    }

    public static Student[] mergeSortInner(Student[] buffer1, Student[] buffer2, int startIndex, int endIndex) {
        if (startIndex >= endIndex - 1) {
            return buffer1;
        }

        int middle = startIndex + (endIndex - startIndex) / 2;
        Student[] sorted1 = mergeSortInner(buffer1, buffer2, startIndex, middle);
        Student[] sorted2 = mergeSortInner(buffer1, buffer2, middle, endIndex);

        int index1 = startIndex;
        int index2 = middle;
        int destIndex = startIndex;
        Student[] result = sorted1 == buffer1 ? buffer2 : buffer1;
        while (index1 < middle && index2 < endIndex) {
            if (sorted1[index1].compareTo(sorted2[index2]) < 0) {
                result[destIndex] = sorted1[index1];
                index1++;
            } else {
                result[destIndex] = sorted2[index2];
                index2++;
            }
            destIndex++;
        }
        while (index1 < middle) {
            result[destIndex] = sorted1[index1];
            index1++;
            destIndex++;
        }
        while (index2 < endIndex) {
            result[destIndex] = sorted2[index2];
            index2++;
            destIndex++;
        }
        return result;
    }
}