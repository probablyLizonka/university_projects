package ru.mirea.lab9;

import java.util.*;

public class SortingTest {
    public static void main(String[] args) {
        System.out.println("Задание 1");

        Student s1 = new Student("КВБО-03-23", 1, "Елизавета", "Супрунова",
                2005, 8, 22);
        Student s2 = new Student("КВБО-03-23", 2, "Мария", "Комлева",
                2005, 9, 16);
        Student s3 = new Student("КВБО-03-23", 3, "Максим", "Орехов",
                2005, 7, 23);
        Student s4 = new Student("КВБО-03-23", 4, "Константин", "Попов",
                2005, 2, 3);

        Student[] iDNumber = new Student[4];
        iDNumber[0] = s1;
        iDNumber[1] = s2;
        iDNumber[3] = s3;
        iDNumber[2] = s4;
        System.out.println("Несортированный\n" + Arrays.toString(iDNumber));

        Student.InsertionSort(iDNumber);
        System.out.println("Отсортированный\n" + Arrays.toString(iDNumber));


        System.out.println("Задание 2");

        Student s5 = new Student("КВБО-03-23", 5, "Максим", "Юрочкин",
                2005, 7, 22);
        Student s6 = new Student("КВБО-03-23", 6, "Егор", "Мезенцев",
                2005, 10, 22);
        Student s7 = new Student("КВБО-03-23", 7, "Алена", "Ефимова",
                2005, 12, 29);
        Student s8 = new Student("КВБО-03-23", 8, "Александр", "Одинцов",
                2005, 5, 7);


        Student[] iDNumber1 = new Student[4];
        iDNumber1[0] = s5;
        iDNumber1[1] = s7;
        iDNumber1[3] = s6;
        iDNumber1[2] = s8;

        List<Student> list = new ArrayList<>(Arrays.asList(iDNumber1));
        list.addAll(Arrays.asList(iDNumber));
        Student[] alliD = list.toArray(new Student[0]);

        System.out.println("Несортированный\n" + Arrays.toString(alliD));

        System.out.println("Отсортированный\n" + Arrays.toString(Student.mergeSort(alliD)));
    }
}






