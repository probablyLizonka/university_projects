package ru.mirea.lab26;

import java.util.*;

public class ex1 {
    public static void main(String[] args) {

        System.out.println("Инвертировать массив чисел.");
        Stack<Integer> stack = new Stack<>();
        Scanner sc = new Scanner(System.in);
        int length, el;


        while (true) {
            try {
                System.out.print("Введите длину массива: ");
                length = sc.nextInt();
                break;
            } catch (InputMismatchException e) {
                System.out.println("Неверный ввод");
                sc.nextLine();
            }
        }

        for (int i = 0; i < length; i++) {
            while (true) {
                try {
                    System.out.print("Введите элемент: ");
                    el = sc.nextInt();
                    stack.push(el);
                    break;
                } catch (InputMismatchException e) {
                    System.out.println("Неверный ввод");
                    sc.nextLine();
                }
            }

        }
        System.out.println("Ваш массив: " + stack);

        ListIterator<Integer> itr = stack.listIterator();
        int temp = 10, need = 10;
        for (int i = 0; i < length - 1; i = i + 2) {
            temp = itr.next();
            int j = 0;
            while (j != length - i - 1) {
                j++;
                need = itr.next();
            }
            itr.set(temp);
            while (j + 1 != 0) {
                j--;
                itr.previous();
            }
            itr.set(need);
            itr.next();
            System.out.println("Ваш массив: " + stack);
        }

    }
}
