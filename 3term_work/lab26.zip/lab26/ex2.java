package ru.mirea.lab26;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ex2<E> implements Iterator<E> {
    private final List<E> list;
    private int currentPosition = 0;

    public ex2(List<E> list) {
        this.list = list;
    }

    @Override
    public void remove() {
        list.remove(currentPosition - 1);
        currentPosition--;
    }

    @Override
    public E next() {
        if (!hasNext()) {
            throw new ArrayIndexOutOfBoundsException("Нет следующего элемента");
        }
        E el = list.get(currentPosition);
        currentPosition = currentPosition + 1;
        return el;
    }

    @Override
    public boolean hasNext() {
        return currentPosition < list.size();
    }

    public static void main(String[] args) {
        List<Integer> list1 = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            list1.add(i);
        }
        System.out.println("Ваш массив: " + list1);
        ex2<Integer> itr = new ex2<>(list1);
        while (itr.hasNext()) {
            Integer i = itr.next();
            System.out.print(i + " ");
            if (i % 2 != 0) {
                itr.remove();
            }
        }
        System.out.println("\nВаш массив: " + list1);
    }
}
