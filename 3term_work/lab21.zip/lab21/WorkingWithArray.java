package ru.mirea.lab21;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

public class WorkingWithArray {
    Scanner sc = new Scanner(System.in);
    Array<String> myArray = new Array<>();
    String[] arrayS = null;
    Integer[] arrayI = null;

    public static <T> List<T> convertArrayToList(T[] array) {
        return List.of(array);
    }

    public void addArray() {
        System.out.println("Введите массив c разделителем ' '.");
        String array = sc.nextLine();
        myArray.fillArray(String[].class, array.split(" "), array.split(" ").length);
        System.out.println("Массив введен.");
    }

    public void getElementByIndex() {
        if (myArray.size() == 0) {
            System.out.println("Массив пустой.");
            return;
        }
        System.out.print("Введите индекс элемента: ");
        try {
            int index = sc.nextInt();
            sc.nextLine();
            System.out.println(myArray.getElement(index));
        } catch (InputMismatchException | IndexOutOfBoundsException e) {
            System.out.println(e.getMessage());
        }
    }

    public void outputArray() {
        if (myArray.size() == 0) {
            System.out.println("Массив пустой.");
            return;
        }
        System.out.print("[");
        for (int i = 0; i < myArray.size(); i++) {
            if (i == myArray.size() - 1) {
                System.out.println(myArray.getElement(i) + "]");
                return;
            }
            System.out.print(myArray.getElement(i) + " ");
        }
    }

    public void addArray2() {
        System.out.println("Задайте тип массива: 1. строки\n2. числа");
        int type = sc.nextInt();
        sc.nextLine();
        System.out.println("Введите массив c разделителем ' '.");
        String line = sc.nextLine();
        arrayS = line.split(" ");
        switch (type) {
            case 1:
                break;
            case 2:
                arrayI = new Integer[arrayS.length];
                for (int i = 0; i < arrayS.length; i++) {
                    arrayI[i] = Integer.parseInt(arrayS[i]);
                }
                break;

            default :
                System.out.println("Ошибка ввода. Введите снова.");

        }

        System.out.println("Массив введен.");
    }

    public void convertArray() {
        if (arrayI != null) {
            System.out.println("Конвертированный массив: " + convertArrayToList(arrayI));
            return;
        }
        System.out.println("Конвертированный массив: " + convertArrayToList(arrayS));
    }

    public void outputArray2() {
        System.out.print("[");
        if (arrayI != null) {
            for (int i = 0; i < arrayI.length; i++) {
                if (i == arrayI.length - 1) {
                    System.out.println(arrayI[i] + "]");
                    return;
                }
                System.out.print(arrayI[i] + " ");
            }
        }
        for (int i = 0; i < arrayS.length; i++) {
            if (i == arrayS.length - 1) {
                System.out.println(arrayS[i] + "]");
                return;
            }
            System.out.print(arrayS[i] + " ");
        }
    }

    public WorkingWithArray() {
        boolean running = true;
        System.out.println("\nЗадание 2 и 3.");
        while (running) {
            System.out.println("""
                    
                    Выберите действие:\
                    
                    1. Ввести массив\
                    
                    2. Получить элемент по индексу\
                    
                    3. Вывести массив\
                    
                    4. Выйти из программы
                    """);
            String choice = sc.nextLine();
            switch (choice) {
                case "1" -> addArray();
                case "2" -> getElementByIndex();
                case "3" -> outputArray();
                case "4" -> running = false;
                default -> System.out.println("Ошибка ввода. Введите снова.");
            }
        }

        running = true;
        System.out.println("\nЗадание 1.");
        while (running) {
            System.out.println("""
                    
                    Выберите действие:\
                    
                    1. Ввести массив\
                    
                    2. Конвертировать массив в список\
                    
                    3. Вывести массив\
                    
                    4. Выйти из программы
                    """);
            String choice = sc.nextLine();
            switch (choice) {
                case "1" -> addArray2();
                case "2" -> convertArray();
                case "3" -> outputArray2();
                case "4" -> running = false;
                default -> System.out.println("Ошибка ввода. Введите снова.");
            }
        }
    }

    public static void main(String[] args) {
        new WorkingWithArray();
    }
}
