package ru.mirea.lab21;

public class Array<T> {
    private T[] array;

    public void fillArray(Class<T[]> c, T[] arr, int len) {
        //array = (T[]) new Object[len];
        //array = (T[]) java.lang.reflect.Array.newInstance(c, len);
        array = c.cast(java.lang.reflect.Array.newInstance(c.getComponentType(), len));
        try {
            for (int i = 0; i < len && i < array.length; i++) {
                array[i] = arr[i];
            }
        } catch (ClassCastException e) {
            System.out.println("Ошибка: Неверный тип данных при заполнении массива.");
        }
    }

    public T getElement(int index) {
        if (index < 0 || index >= array.length) {
            throw new IndexOutOfBoundsException("Индекс выходит за пределы массива.");
        }
        return array[index];
    }

    public int size() {
        if (array == null) {
            return 0;
        }
        return array.length;
    }
}
