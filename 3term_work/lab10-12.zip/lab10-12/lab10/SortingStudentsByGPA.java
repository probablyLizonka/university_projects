package ru.mirea.lab10;

import java.util.*;

public class SortingStudentsByGPA {
    static Scanner sc = new Scanner(System.in);

    // быстрая сортировка
    public static void quickSort(Students[] sortArr, int low, int high) {
        if (sortArr.length == 0 || low >= high) return;

        int middle = low + (high - low) / 2;
        Students border = sortArr[middle];

        int i = low, j = high;
        while (i <= j) {
            while (new TotalMarkComparator().compare(sortArr[i], border) < 0) {
                i++;
            }
            while (new TotalMarkComparator().compare(sortArr[j], border) > 0) {
                j--;
            }
            if (i <= j) {
                Students swap = sortArr[i];
                sortArr[i] = sortArr[j];
                sortArr[j] = swap;
                i++;
                j--;
            }
        }

        if (low < j) {
            quickSort(sortArr, low, j);
        }
        if (high > i) {
            quickSort(sortArr, i, high);
        }
    }

    public static void outArray(TreeSet<Students> arr) {
        for (Students s : arr) {
            System.out.println(s.getSurname() + ": " + s.getTotal_mark());
        }
    }

    public static void setArray(TreeSet<Students> arr) {
        System.out.println("Введите количество студентов");
        String n = sc.nextLine();
        while (!Character.isDigit(n.charAt(0))) {
            System.out.println("Введите заново");
            n = sc.nextLine();
        }

        for (int i = 0; i < Integer.parseInt(n); i++) {
            System.out.println("Введите данные о студенте");
            System.out.println("Фамилия");
            String surname = sc.nextLine();
            System.out.println("Имя");
            String name = sc.nextLine();
            System.out.println("Группа");
            String group = sc.nextLine();
            System.out.println("Год обучения");
            String year = sc.nextLine();
            while (!Character.isDigit(year.charAt(0))) {
                System.out.println("Введите заново");
                year = sc.nextLine();
            }
            System.out.println("Средний балл");
            String tm = sc.nextLine();
            while (!Character.isDigit(tm.charAt(0))) {
                System.out.println("Введите заново");
                tm = sc.nextLine();
            }

            arr.add(new Students(group, name, surname, Double.parseDouble(tm), Integer.parseInt(year)));
        }
    }

    public static void main(String[] args) {
        Comparator<Students> studentsComparator = new TotalMarkComparator().thenComparing(new SurnameComparator());
        TreeSet<Students> iDNumber = new TreeSet<>(new SurnameComparator());
        iDNumber.add(new Students("КВБО-03-23", "Елизавета", "Супрунова", 5, 2));
        iDNumber.add(new Students("КВБО-03-23", "Мария", "Комлева", 5, 2));
        iDNumber.add(new Students("КВБО-03-23", "Максим", "Орехов", 3.9, 2));
        iDNumber.add(new Students("КВБО-03-23", "Константин", "Попов", 4.2, 2));

        System.out.println("Сортировка только по фамилиям\nФамилия: Средний балл");
        outArray(iDNumber);

        Students[] a = new Students[4];
        a = iDNumber.toArray(a);

        System.out.println("\nСортировка только по среднему баллу\nФамилия: Средний балл");
        quickSort(a, 0, a.length - 1);
        for (Students s : a) {
            System.out.println(s.getSurname() + ": " + s.getTotal_mark());
        }

        TreeSet<Students> iDNumber1 = new TreeSet<>(studentsComparator);
        SortingStudentsByGPA.setArray(iDNumber1);

        //iDNumber1.addAll(iDNumber);
        System.out.println("\nСортировка и по фамилиям и по среднему баллу\nФамилия: Средний балл");
        outArray(iDNumber1);

        System.out.println("""
                
                Объединение двух списков и сортировка по фамилиям и по среднему баллу\
                
                Фамилия: Средний балл""");
        ArrayList<Students> as = new ArrayList<>();
        as.addAll(iDNumber);
        as.addAll(iDNumber1);
        TreeSet<Students> list = new TreeSet<>(studentsComparator);
        list.addAll(as);
        outArray(list);
    }
}

class TotalMarkComparator implements Comparator<Students> {
    @Override
    public int compare(Students o1, Students o2) {
        return Double.compare(o1.getTotal_mark(), o2.getTotal_mark());

    }
}

class SurnameComparator implements Comparator<Students> {
    @Override
    public int compare(Students o1, Students o2) {
        return o1.getSurname().compareTo(o2.getSurname());
    }
}
