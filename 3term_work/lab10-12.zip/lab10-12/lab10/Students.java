package ru.mirea.lab10;

public class Students {
    private String name;
    private String surname;
    private int year;
    private String group;
    private double total_mark;

    public Students(String group, String name, String surname, double total_mark, int year) {
        this.group = group;
        this.name = name;
        this.surname = surname;
        this.total_mark = total_mark;
        this.year = year;
    }

    public String getGroup() {
        return group;
    }

    public String getName() {
        return name;
    }

    public String getSurname() {
        return surname;
    }

    public double getTotal_mark() {
        return total_mark;
    }

    public int getYear() {
        return year;
    }

    public void setGroup(String group) {
        this.group = group;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public void setTotal_mark(double total_mark) {
        this.total_mark = total_mark;
    }

    public void setYear(int year) {
        this.year = year;
    }
}
