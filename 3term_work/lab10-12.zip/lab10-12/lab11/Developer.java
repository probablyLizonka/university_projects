package ru.mirea.lab11;

import java.text.SimpleDateFormat;
import java.util.*;

public class Developer {
    static Scanner sc = new Scanner(System.in);

    public static void comp(long x, long y) {
        if (x < y) {
            System.out.println("LinkedList быстрее");
        } else {
            System.out.println("ArrayList быстрее");
        }
    }

    public static Calendar dateCreator(int year, int month, int data, int hour, int am_pm, int min) {
        Calendar cal = Calendar.getInstance();
        cal.set(year, month, data, hour, min);
        cal.set(Calendar.AM_PM, am_pm);
        return cal;
    }

    public static String dataMaker(String data, int n) {
        while (!Character.isDigit(data.charAt(0)) || !(Integer.parseInt(data) > 0 && Integer.parseInt(data) <= n)) {
            System.out.println("Введите дату в пределах 1 - " + n);
            data = sc.nextLine();
        }
        return data;
    }

    public static void main(String[] args) {
        SimpleDateFormat dateFormatter = new SimpleDateFormat("hh:mm:ss a d MMMM yyyy, EEEE");

        System.out.println("Разработчик: Супрунова Елизавета");

        Date start_date = new Date();
        System.out.println("Дата получения задания: " + dateFormatter.format(start_date));
        long c = System.currentTimeMillis();

        try {

            System.out.println("Введите дату");
            System.out.println("Год (после 1970)");
            String year = sc.nextLine();
            while (!Character.isDigit(year.charAt(0)) || !(1970 <= Integer.parseInt(year))) {
                System.out.println("Введите заново");
                year = sc.nextLine();
            }
            System.out.println("Месяц (указать числом)");
            String month = sc.nextLine();
            while (!Character.isDigit(month.charAt(0)) || !(0 < Integer.parseInt(month) && Integer.parseInt(month) < 13)) {
                System.out.println("Введите заново");
                month = sc.nextLine();
            }
            System.out.println("Число");
            String data = sc.nextLine();
            while (!Character.isDigit(month.charAt(0))) {
                System.out.println("Введите число");
                data = sc.nextLine();
            }
            if (Integer.parseInt(month) == 2 && Integer.parseInt(year) % 4 == 0) {
                data = dataMaker(data, 29);
            } else if (Integer.parseInt(month) == 2) {
                data = dataMaker(data, 28);
            } else if (Integer.parseInt(month) == 1 || Integer.parseInt(month) == 3 || Integer.parseInt(month) == 5 ||
                    Integer.parseInt(month) == 7 || Integer.parseInt(month) == 8 || Integer.parseInt(month) == 10 ||
                    Integer.parseInt(month) == 12) {
                data = dataMaker(data, 31);
            } else {
                data = dataMaker(data, 30);
            }
            System.out.println("Час (0 - 23)");
            String hour = sc.nextLine();
            while (!Character.isDigit(hour.charAt(0)) || !(0 <= Integer.parseInt(hour) && Integer.parseInt(hour) <= 23)) {
                System.out.println("Введите заново");
                hour = sc.nextLine();
            }
            int am_pm;
            if (Integer.parseInt(hour) >= 12) {
                am_pm = 1;
            } else {
                am_pm = 0;
            }
            System.out.println("Минуты (0 - 59)");
            String min = sc.nextLine();
            while (!Character.isDigit(min.charAt(0)) || !(0 <= Integer.parseInt(min) && Integer.parseInt(min) <= 59)) {
                System.out.println("Введите заново");
                min = sc.nextLine();
            }

            Calendar caldata = Developer.dateCreator(Integer.parseInt(year), Integer.parseInt(month) - 1,
                    Integer.parseInt(data), Integer.parseInt(hour), am_pm, Integer.parseInt(min));
            System.out.println("Пользовательская дата с типом Calendar: " + dateFormatter.format(caldata.getTime()));
            Date dateData = caldata.getTime();
            System.out.println("Пользовательская дата с типом Date: " + dateFormatter.format(dateData));
        } catch (NumberFormatException | StringIndexOutOfBoundsException e) {
            System.out.println("Программа не сработала. Вы ввели не ЦЕЛОЕ число");
        }

        int size = 1000;
        ArrayList<Integer> arr1 = new ArrayList<>();
        LinkedList<Integer> arr2 = new LinkedList<>();
        for (int i = 0; i < size; i++) {
            arr1.add(i);
            arr2.add(i);
        }

        long s1_1 = System.nanoTime();
        int size1 = 100;
        for (int i = 0; i < size1; i++) {
            arr1.addFirst(i);
        }
        long e1_1 = System.nanoTime() - s1_1;

        long s1_2 = System.nanoTime();
        for (int i = 0; i < size1; i++) {
            arr2.addFirst(i);
        }
        long e1_2 = System.nanoTime() - s1_2;

        long s2_1 = System.nanoTime();
        for (int i = 0; i < size1; i++) {
            arr1.addLast(i);
        }
        long e2_1 = System.nanoTime() - s2_1;

        long s2_2 = System.nanoTime();
        for (int i = 0; i < size1; i++) {
            arr2.addLast(i);
        }
        long e2_2 = System.nanoTime() - s2_2;

        long s3_1 = System.nanoTime();
        int size2 = 50;
        for (int i = 0; i < size2; i++) {
            arr1.removeFirst();
        }
        long e3_1 = System.nanoTime() - s3_1;

        long s3_2 = System.nanoTime();
        for (int i = 0; i < size1; i++) {
            arr2.removeFirst();
        }
        long e3_2 = System.nanoTime() - s3_2;

        long s4_1 = System.nanoTime();
        for (int i = 0; i < size1; i++) {
            arr1.removeLast();
        }
        long e4_1 = System.nanoTime() - s4_1;

        long s4_2 = System.nanoTime();
        for (int i = 0; i < size1; i++) {
            arr2.removeLast();
        }
        long e4_2 = System.nanoTime() - s4_2;

        System.out.println("Сравнение работы LinkedList и ArrayList");
        System.out.println("Время вставки элемента в начало" + "LinkedList: " + (s1_2 - e1_2));
        System.out.println("Время вставки элемента в начало" + "ArrayList: " + (s1_1 - e1_1));
        comp((s1_2 - e1_2), (s1_1 - e1_1));

        System.out.println("Время вставки элемента в конец" + "LinkedList: " + (s2_2 - e2_2));
        System.out.println("Время вставки элемента в конец" + "ArrayList: " + (s2_1 - e2_1));
        comp((s2_2 - e2_2), (s2_1 - e2_1));

        System.out.println("Время удаления элемента из начала" + "LinkedList: " + (s3_2 - e3_2));
        System.out.println("Время удаления элемента из начала" + "ArrayList: " + (s3_1 - e3_1));
        comp((s3_2 - e3_2), (s3_1 - e3_1));

        System.out.println("Время удаления элемента из конца" + "LinkedList: " + (s4_2 - e4_2));
        System.out.println("Время удаления элемента из конца" + "ArrayList: " + (s4_1 - e4_1));
        comp((s4_2 - e4_2), (s4_1 - e4_1));

        Date end_date = new Date();
        System.out.println("Дата выполнения задания: " + dateFormatter.format(end_date));
        long s = System.currentTimeMillis() - c;
        System.out.println("Временя выполнения кода: " + s / 1000 + " секунд");

    }
}
