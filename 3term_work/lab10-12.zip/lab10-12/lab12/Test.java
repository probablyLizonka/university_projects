package ru.mirea.lab12;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Test extends JFrame {
    Canvas canvas, canvas1;
    private Timer timer;
    private int count = 0;
    private int max_quantity;
    private Image[] images;
    private JToggleButton buttonn = new JToggleButton("stop");

    public Test(String winTitle, int w, int h) {
        super(winTitle);
        JPanel[] pnl = new JPanel[4];

        JPanel buttonsPanel = new JPanel();
        JPanel canvasPanel = new JPanel();

        JButton button = new JButton("Рисовать");
        JButton button1 = new JButton("Очистить холст");

        ActionListener buttonsListener = new ButtonsListener();
        button.setActionCommand("Draw");
        button1.setActionCommand("Clean");
        button.addActionListener(buttonsListener);
        button1.addActionListener(buttonsListener);

        buttonsPanel.add(button);
        buttonsPanel.add(button1);

        canvas = new Canvas();
        canvas.setBackground(Color.GRAY);
        canvas.setSize(w / 2, h / 2);
        canvasPanel.add(canvas);

        pnl[0] = new JPanel();
        pnl[2] = new JPanel();
        pnl[3] = new JPanel();
        pnl[0].add(BorderLayout.NORTH, buttonsPanel);
        pnl[0].add(BorderLayout.CENTER, canvasPanel);


        String[] names = {"cat1.png", "cat2.png", "cat3.png", "cat4.png", "cat5.png", "cat6.png"};

        max_quantity = names.length;
        images = new Image[max_quantity];

        buttonn.addItemListener(e -> {
            int state = e.getStateChange();
            if (state == ItemEvent.SELECTED) {
                timer.stop();
                buttonn.setText("start");
            } else {
                timer.start();
                buttonn.setText("stop");
            }
        });

        try {
            for (int i = 0; i < max_quantity; i++) {
                images[i] = new ImageIcon("C:\\Users\\volg2\\OneDrive\\Изображения\\учеба\\"
                        + names[i]).getImage();
            }
        } catch (NullPointerException e) {
            System.out.println("Problem is: " + e);
        }


        pnl[1] = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D fig = (Graphics2D) g;
                fig.drawImage(images[count], 10, 50, w / 2 - 50, h / 2 - 50, this);
            }
        };

        timer = new Timer(100, ev -> {
            count++;
            if (count > max_quantity - 1) {
                count = 0;
            }
            repaint();
        });
        timer.start();

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(buttonn);

        pnl[1].add(BorderLayout.SOUTH, buttonPanel);

        canvas1 = new Canvas();
        canvas1.setBackground(Color.GRAY);
        canvas1.setSize(w / 2, h / 2);
        canvas1.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                int circleW = 20, circleH = 20;
                int half = circleW / 2;
                Graphics g = canvas1.getGraphics();
                g.setColor(Color.red);
                g.fillOval(e.getX() - half, e.getY() - half, circleW, circleH);
            }
        });

        pnl[2].add(new TextField("Тут можно рисовать кликом мыши"));
        pnl[2].add(BorderLayout.CENTER, canvas1);

        TextField tf = new TextField("Поставьте плюс, пожалуйста!");
        tf.setFont(new Font("Serif", Font.ITALIC, 30));
        pnl[3].add(tf);

        setLayout(new GridLayout(2, 2));
        add(pnl[0]);
        add(pnl[1]);
        add(pnl[2]);
        add(pnl[3]);

        getContentPane();
    }

    class ButtonsListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String command = e.getActionCommand();
            int circleW = 50, circleH = 50;
            Graphics gr = canvas.getGraphics();
            for (int i = 0; i < 20; i++) {
                int r = (int) (Math.random() * 255);
                int b = (int) (Math.random() * 255);
                int g = (int) (Math.random() * 255);
                Color c = new Color(r, g, b);
                int x = (int) (Math.random() * (canvas.getWidth() - circleW));
                int y = (int) (Math.random() * (canvas.getHeight() - circleH));

                if (command.equals("Draw")) {
                    if (i % 2 == 0) {
                        Circle f = new Circle(c, x, y, 50);
                        f.draw(gr);
                    } else {
                        Rectangle f = new Rectangle(c, x, y, 50, 50);
                        f.draw(gr);
                    }
                }
            }
            if (command.equals("Clean")) {
                //canvas.update(gr);
                gr.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
            }
        }
    }


    public static void main(String[] args) {
        int w = 1400, h = 800;
        Test t = new Test("Фигуры, бегущий котик и рисование", w, h);
        t.setSize(w, h);
        t.setResizable(false);
        t.setDefaultCloseOperation(EXIT_ON_CLOSE);
        t.setVisible(true);
    }
}