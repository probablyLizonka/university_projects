package ru.mirea.lab12;

import java.awt.*;

public abstract class Shape {
    Color colour;
    int x, y;

    public Shape(Color colour, int x, int y) {
        this.colour = colour;
        this.x = x;
        this.y = y;
    }

    public abstract void draw(Graphics g);
}

class Circle extends Shape {
    private int radius;

    public Circle(Color colour, int x, int y, int radius) {
        super(colour, x, y);
        this.radius = radius;
    }

    @Override
    public void draw(Graphics g) {
        g.setColor(colour);
        g.fillOval(x, y, radius, radius);
    }

}

class Rectangle extends Shape {
    private int length;
    private int width;

    public Rectangle(Color colour, int x, int y, int length, int width) {
        super(colour, x, y);
        this.length = length;
        this.width = width;
    }

    @Override
    public void draw(Graphics g) {
        g.setColor(colour);
        g.fillRect(x, y, width, length);
    }
}
