package ru.mirea.lab13;

import java.util.Arrays;

public class Shirt {
    private String id;
    private String model;
    private String color;
    private String size;

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    @Override
    public String toString() {
        return "Shirt {" +
                "id=" + id +
                ", model='" + model + '\'' +
                ", color='" + color + '\'' +
                ", size='" + size + '\'' +
                '}';
    }

    public static Shirt[] setShirt(String[] arr) {
        Shirt[] s = new Shirt[arr.length];
        for (int i = 0; i < arr.length; i ++) {
            s[i] = new Shirt();
            String[] as = arr[i].split(",");
            s[i].setId(as[0]);
            s[i].setModel(as[1]);
            s[i].setColor(as[2]);
            s[i].setSize(as[3]);
        }
        return s;
    }
}
