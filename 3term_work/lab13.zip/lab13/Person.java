package ru.mirea.lab13;

public class Person {
    private StringBuilder surname;
    private StringBuilder name;
    private StringBuilder secondName;

    public Person(StringBuilder name, StringBuilder secondName, StringBuilder surname) {
        this.name = name;
        this.secondName = secondName;
        this.surname = surname;
    }

    public Person(StringBuilder surname) {
        this.surname = surname;
    }

    public Person(StringBuilder name, StringBuilder surname) {
        this.name = name;
        this.surname = surname;
    }


    public StringBuilder returnName() {
        if (name == null) {
            return new StringBuilder(surname);
        }
        if (secondName == null) {
            return  new StringBuilder(surname + " " + name);
        }
        return new StringBuilder(surname + " " + name + " " + secondName);
    }
}
