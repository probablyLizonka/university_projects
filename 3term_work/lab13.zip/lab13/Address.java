package ru.mirea.lab13;

import java.util.Scanner;
import java.util.StringTokenizer;

public class Address {
    Scanner sc = new Scanner(System.in);

    private StringBuilder country;
    private StringBuilder region;
    private StringBuilder city;
    private StringBuilder street;
    private StringBuilder house;
    private StringBuilder corpus;
    private StringBuilder flat;

    public void setAddress(String s) {
        while (!(s.contains(". ")) && !(s.contains("; ")) && !(s.contains(", "))) {
            System.out.println("""
                        Формат ввода не соотвествует. \
                        
                        Напишите в формате: Страна[d] Регион[d] Город[d] Улица[d] Дом[d] Корпус[d] Квартира,\
                        
                        где ([d] – разделитель, например ',', ';', '.'""");
            s = sc.nextLine();
        }
        String[] a;
        if (s.contains(",")) {
            a = s.split(", ");
            while (a.length != 7) {
                System.out.println("""
                        Формат ввода не соотвествует. \
                        
                        Напишите в формате: Страна[d] Регион[d] Город[d] Улица[d] Дом[d] Корпус[d] Квартира,\
                        
                        где ([d] – разделитель, например ',', ';', '.'""");
                s = sc.nextLine();
                a = s.split(", ");
            }
            country = new StringBuilder(a[0]);
            region = new StringBuilder(a[1]);
            city = new StringBuilder(a[2]);
            street = new StringBuilder(a[3]);
            house = new StringBuilder(a[4]);
            corpus = new StringBuilder(a[5]);
            flat = new StringBuilder(a[6]);
        } else if (s.contains(". ")) {
            StringTokenizer stringTokenizer = new StringTokenizer(s, ". ");
            while (stringTokenizer.countTokens() != 7) {
                System.out.println("""
                        Формат ввода не соотвествует. \
                        
                        Напишите в формате: Страна[d] Регион[d] Город[d] Улица[d] Дом[d] Корпус[d] Квартира,\
                        
                        где ([d] – разделитель, например ',', ';', '.'""");
                s = sc.nextLine();
                stringTokenizer = new StringTokenizer(s, ". ");
            }
            country = new StringBuilder(stringTokenizer.nextToken());
            region = new StringBuilder(stringTokenizer.nextToken());
            city = new StringBuilder(stringTokenizer.nextToken());
            street = new StringBuilder(stringTokenizer.nextToken());
            house = new StringBuilder(stringTokenizer.nextToken());
            corpus = new StringBuilder(stringTokenizer.nextToken());
            flat = new StringBuilder(stringTokenizer.nextToken());
        } else {
            StringTokenizer stringTokenizer1 = new StringTokenizer(s, "; ");
            while (stringTokenizer1.countTokens() != 7) {
                System.out.println("""
                        Формат ввода не соотвествует. \
                        
                        Напишите в формате: Страна[d] Регион[d] Город[d] Улица[d] Дом[d] Корпус[d] Квартира,\
                        
                        где ([d] – разделитель, например ',', ';', '.'""");
                s = sc.nextLine();
                stringTokenizer1 = new StringTokenizer(s, ". ");
            }
            country = new StringBuilder(stringTokenizer1.nextToken());
            region = new StringBuilder(stringTokenizer1.nextToken());
            city = new StringBuilder(stringTokenizer1.nextToken());
            street = new StringBuilder(stringTokenizer1.nextToken());
            house = new StringBuilder(stringTokenizer1.nextToken());
            corpus = new StringBuilder(stringTokenizer1.nextToken());
            flat = new StringBuilder(stringTokenizer1.nextToken());
        }
        System.out.println(this);
    }

    @Override
    public String toString() {
        return "Address{" +
                "country=" + country +
                ", region=" + region +
                ", city=" + city +
                ", street=" + street +
                ", house=" + house +
                ", corpus=" + corpus +
                ", flat=" + flat +
                '}';
    }
}
