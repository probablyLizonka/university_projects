package ru.mirea.lab13;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Test {
    public static void ex1(String s) {
        System.out.println("Изначальная строка: " + s);
        System.out.println("Последний символ: " + s.charAt(s.length() - 1));

        if (s.endsWith("!!!")) {
            System.out.println("Строка заканчивается '!!!'");
        } else {
            System.out.println("Строка НЕ заканчивается '!!!'");
        }

        if (s.startsWith("I like")) {
            System.out.println("Строка начинается с 'I like'");
        } else {
            System.out.println("Строка НЕ начинается с 'I like'");
        }

        if (s.contains("Java")) {
            System.out.println("Строка содержит 'Java'");
            System.out.println("Позиция 'Java' в строке " + ": " + s.indexOf("Java"));
            System.out.println("Вырезанная строка 'Java': " + s.substring(s.indexOf("Java"), s.indexOf("Java") + 4));
        } else {
            System.out.println("Строка НЕ содержит 'Java'");
        }

        System.out.println("Строка " + s + " с заменёнными 'а' на 'о': " + s.replace("a", "o"));

        System.out.println("К верхнему регистру: " + s.toUpperCase());
        System.out.println("К нижнему регистру: " + s.toLowerCase());

    }

    // Риверс длинной строки с помощью String и StringBuffer
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        long beginTime, elapsedTime;

        // Build a long string
        String str = "";
        int size = 16536;
        char ch = 'a';

        // Эталонное время в наносекундах
        beginTime = System.nanoTime();
        for (int count = 0; count < size; count++) {
            str += ch;
            ch++;
            if (ch > 'z') {
                ch = 'a';
            }
        }
        elapsedTime = System.nanoTime() - beginTime;
        System.out.println("Elapsed Time is " + elapsedTime / 1000 + " usec (Build String)");


        //Риверс строки, строим другую строку за символом в обратном порядке
        String strReverse = "";

        beginTime = System.nanoTime();
        for (int pos = str.length() - 1; pos >= 0; pos--) {
            strReverse += str.charAt(pos); // Конкатенация
        }
        elapsedTime = System.nanoTime() - beginTime;
        System.out.println("Elapsed Time is " + elapsedTime / 1000 + " usec (Using String to reverse)");


        // Риверс строки через пустой StringBuffer путем добавления символов в обратном порядке
        beginTime = System.nanoTime();
        StringBuffer sBufferReverse = new StringBuffer(size);
        for (int pos = str.length() - 1; pos >= 0; pos--) {
            sBufferReverse.append(str.charAt(pos)); // append
        }
        elapsedTime = System.nanoTime() - beginTime;
        System.out.println("Elapsed Time is " + elapsedTime / 1000 + " usec (Using StringBuffer to reverse)");


        //Reverse a String by creating a StringBuffer with the given String and invoke its reverse()
        beginTime = System.nanoTime();
        StringBuffer sBufferReverseMethod = new StringBuffer(str);
        sBufferReverseMethod.reverse(); // use reverse()method
        elapsedTime = System.nanoTime() - beginTime;
        System.out.println("Elapsed Time is " + elapsedTime / 1000 + " usec (Using StringBuffer's reverse() method)");


        //Reverse a String via an empty StringBuilder by appending characters in the reverse order
        beginTime = System.nanoTime();
        StringBuilder sBuilderReverse = new StringBuilder(size);
        for (int pos = str.length() - 1; pos >= 0; pos--) {
            sBuilderReverse.append(str.charAt(pos));
        }
        elapsedTime = System.nanoTime() - beginTime;
        System.out.println("Elapsed Time is " + elapsedTime / 1000 + " usec (Using StringBuilder to reverse)");


        //Reverse a String by creating a StringBuilder with the given String and invoke its reverse()
        beginTime = System.nanoTime();
        StringBuilder sBuilderReverseMethod = new StringBuilder(str);
        sBuilderReverseMethod.reverse();
        elapsedTime = System.nanoTime() - beginTime;
        System.out.println("Elapsed Time is " + elapsedTime / 1000 + " usec (Using StringBuidler's reverse() method)");

        System.out.println("-----------------");

        System.out.println("Задание 1");
        System.out.println("Попытка 1");
        ex1("I like Java!!!");
        System.out.println("Попытка 2");
        ex1("Hi, my name is Lisa^");

        System.out.println("\nЗадание 2");
        Person p1 = new Person(new StringBuilder("Супрунова"));
        Person p2 = new Person(new StringBuilder("Максим"), new StringBuilder("Александрович"),
                new StringBuilder("Юрочкин"));
        Person p3 = new Person(new StringBuilder("Мария"), new StringBuilder("Комлева"));
        System.out.println(p1.returnName());
        System.out.println(p2.returnName());
        System.out.println(p3.returnName());

        System.out.println("\nЗадание 3");
        System.out.println("""
                Введите адрес в формате: \
                
                Страна[d] Регион[d] Город[d] Улица[d] Дом[d] Корпус[d] Квартира, \
                
                где ([d] – разделитель, например ',', ';', '.')""");
        String s = sc.nextLine();
        Address add1 = new Address();
        add1.setAddress(s);

        System.out.println("\nЗадание 4");
        String[] shirts = new String[11];
        shirts[0] = "S001,Black Polo Shirt,Black,XL";
        shirts[1] = "S002,Black Polo Shirt,Black,L";
        shirts[2] = "S003,Blue Polo Shirt,Blue,XL";
        shirts[3] = "S004,Blue Polo Shirt,Blue,M";
        shirts[4] = "S005,Tan Polo Shirt,Tan,XL";
        shirts[5] = "S006,Black T-Shirt,Black,XL";
        shirts[6] = "S007,White T-Shirt,White,XL";
        shirts[7] = "S008,White T-Shirt,White,L";
        shirts[8] = "S009,Green T-Shirt,Green,S";
        shirts[9] = "S010,Orange T-Shirt,Orange,S";
        shirts[10] = "S011,Maroon Polo Shirt,Maroon,S";

        Shirt[] sh = Shirt.setShirt(shirts);
        for (int i = 0; i < 11; i++) {
            System.out.println(sh[i]);
        }

        System.out.println("\nЗадание 5");
        System.out.println("Введите номер телефона");
        String s1 = sc.nextLine();
        System.out.println(Number.normalize(s1));

        System.out.println("\nЗадание 6");
        try {
            BufferedReader console = new BufferedReader(new InputStreamReader(System.in));
            System.out.println("Введите путь файла");
            // C:\\Users\\volg2\\OneDrive\\Документы\\уник\\программирование\\джава\\lab13ex6.txt
            String fileName = console.readLine();
            BufferedReader fReader = new BufferedReader(new FileReader(fileName));
            List<String> wordsList = new ArrayList<>();
            while (fReader.ready()) {
                String[] splitted = fReader.readLine().split(" ");
                wordsList.addAll(Arrays.asList(splitted));
            }
            fReader.close();

            StringBuilder result = getLine(wordsList.toArray(new String[0]));
            System.out.println(result);
        } catch (IOException e) {
            System.out.println("Программа не cработала. Что-то не так с файлом");
        }
    }

    public static StringBuilder getLine(String... words) {
        StringBuilder sb = new StringBuilder();
        if (words == null || words.length == 0) {
            return sb;
        }

        sb.append(words[0]);

        for (int j = 0; j < words.length - 1; j++) {
            for (int i = 1; i < words.length; i++) {
                if (words[i] == null) {
                    continue;
                }
                if (sb.toString().toLowerCase().charAt(sb.length() - 1) == words[i].toLowerCase().charAt(0)) {
                    sb.append(" ").append(words[i]);
                    words[i] = null;
                }
            }
        }

        return sb;
    }
}