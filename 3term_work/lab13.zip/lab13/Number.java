package ru.mirea.lab13;

import java.util.Scanner;

public class Number {
    private int phone;
    static Scanner sc = new Scanner(System.in);

    public static boolean isD(String s) {
        for (int i = 0; i < s.length(); i++) {
            if (!(Character.isDigit(s.charAt(i)))) {
                return true;
            }
        }
        return false;
    }

    public static String normalize(String s) {
        while (!(s.length() >= 11 && s.length() < 13) || isD(s)) {
            System.out.println("Вы ввели номер неправильно");
            s = sc.nextLine();
        }
        if (s.length() == 11) {
            if (Integer.parseInt(String.valueOf(s.charAt(0))) == 8) {
                System.out.println(s.charAt(0));
                return s.charAt(0) + "-" + s.substring(1, 4) + "-" + s.substring(4, 7)
                        + "-" + s.substring(7);
            } else {
                return "+" + s.charAt(0) + "-" + s.substring(1, 4) + "-" + s.substring(4, 7)
                        + "-" + s.substring(7);
            }
        } else {
            return "+" + s.substring(0, 2) + "-" + s.substring(2, 5) + "-" + s.substring(5, 8)
                    + "-" + s.substring(8);

        }
    }
}
