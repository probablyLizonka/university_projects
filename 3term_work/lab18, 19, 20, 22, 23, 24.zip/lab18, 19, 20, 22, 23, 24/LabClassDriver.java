package ru.mirea.lab19;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Scanner;

public class LabClassDriver {
    public static void main(String[] args) {
        new LabClassUI();
    }
}

class LabClassUI {
    Scanner sc = new Scanner(System.in);
    LabClass labClass = new LabClass();

    public LabClassUI() {
        boolean running = true;
        while (running) {
            System.out.println("""
                    
                    Выберите действие:\
                    
                    1. Добавить студента\
                    
                    2. Сортировать студентов по среднему баллу\
                    
                    3. Найти студента по ФИО\
                    
                    4. Вывести список студентов\
                    
                    5. Выйти""");

            String choice = sc.nextLine();

            switch (choice) {
                case "1" -> labClass.addStudent();
                case "2" -> labClass.sortStudents();
                case "3" -> labClass.findStudent();
                case "4" -> labClass.printStudents();
                case "5" -> running = false;
                default -> System.out.println("Ошибка ввода. Введите снова.");
            }
        }
    }

}


class LabClass implements Comparator<Student> {
    Scanner sc = new Scanner(System.in);
    private final ArrayList<Student> students = new ArrayList<>();

    // быстрая сортировка
    public void quickSort(ArrayList<Student> sortArr, int low, int high) {
        if (sortArr.isEmpty() || low >= high) return;

        int middle = low + (high - low) / 2;
        Student border = sortArr.get(middle);

        int i = low, j = high;
        while (i <= j) {
            while (compare(sortArr.get(i), border) < 0) {
                i++;
            }
            while (compare(sortArr.get(j), border) > 0) {
                j--;
            }
            if (i <= j) {
                Student swap = sortArr.get(i);
                sortArr.add(i, sortArr.get(j));
                sortArr.remove(i + 1);
                sortArr.add(j, swap);
                sortArr.remove(j + 1);
                i++;
                j--;
            }
        }

        if (low < j) {
            quickSort(sortArr, low, j);
        }
        if (high > i) {
            quickSort(sortArr, i, high);
        }
    }

    @Override
    public int compare(Student o1, Student o2) {
        return Double.compare(o1.getGrade(), o2.getGrade());
    }

    public void addStudent() {
        try {
            System.out.println("Введите ФИО студента");
            String FIO = sc.nextLine();
            Student student = new Student();
            student.setFullName(FIO);
            student.EmptyFIO();
            System.out.println("Введите средний балл студента");
            String avgrade = sc.nextLine();
            while (!Character.isDigit(avgrade.charAt(0))) {
                System.out.println("Вы ввели не число. Введите средний балл студента заново");
                avgrade = sc.nextLine();
            }
            student.setGrade(Double.parseDouble(avgrade));
            students.add(student);
            System.out.println("Студент добавлен");
        } catch (EmptyStringException e) {
            System.out.println(e.getMessage());
            System.out.println("Исключение " + e.getClass().getSimpleName() + " обработано.");
        }
    }

    public void sortStudents() {
        if (students.isEmpty()) {
            System.out.println("Студенты не введены");
            return;
        }
        quickSort(students, 0, students.toArray().length - 1);
        printStudents();
    }

    public void findStudent() {
        if (students.isEmpty()) {
            System.out.println("Студенты не введены");
            return;
        }
        try {
            System.out.print("Введите ФИО студента для поиска: ");
            String fullName = sc.nextLine();
            Student student = new Student();
            student.setFullName(fullName);
            student.EmptyFIO();
            for (int i = 0; i < students.toArray().length; i++) {
                if (students.get(i).getFullName().equals(fullName)) {
                    System.out.println("Найден студент: " + students.get(i));
                    return;
                }
            }
            throw new StudentNotFoundException("Студент не найден");

        } catch (StudentNotFoundException | EmptyStringException e) {
            System.out.println("Ошибка: " + e.getMessage());
        }
    }

    public void printStudents() {
        if (students.isEmpty()) {
            System.out.println("Студенты не введены");
            return;
        }
        for (int i = 0; i < students.toArray().length; i++) {
            System.out.println(students.get(i));
        }
    }
}

class Student {
    private String fullName;
    private double grade;

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public void setGrade(double grade) {
        this.grade = grade;
    }

    public String getFullName() {
        return fullName;
    }

    public double getGrade() {
        return grade;
    }

    public void EmptyFIO() throws EmptyStringException {
        if (fullName.isEmpty()) {
            throw new EmptyStringException("ФИО студента не задано");
        }
    }

    @Override
    public String toString() {
        return "Student{" +
                "fullName='" + fullName + '\'' +
                ", grade=" + grade +
                '}';
    }
}

class EmptyStringException extends Exception {
    public EmptyStringException(String message) {
        super(message);
    }
}

class StudentNotFoundException extends Exception {
    public StudentNotFoundException(String message) {
        super(message);
    }
}