package ru.mirea.lab23;

import java.util.Objects;

public class LinkedQueue implements Queue {
    private static class Node {
        Object value;
        Node next;

        //value != null

        public Node(Object value) {
            Objects.requireNonNull(value);
            this.value = value;
        }
    }

    /* Инвариант:
    size >= 0 */

    private Node head = null;
    private Node tail = null;
    private int size = 0;

    // Pred: item != null
    // Post: size' = size + 1
    @Override
    public void enqueue(Object item) {
        Node newNode = new Node(item);
        if (tail != null) {
            tail.next = newNode;
        }
        tail = newNode;
        if (head == null) {
            head = newNode;
        }
        size++;
    }

    // Pred: size > 0
    // Post: output = head
    @Override
    public Object element() {
        if (isEmpty()) {
            throw new IllegalStateException("Очередь пустая.");
        }
        return head.value;
    }

    // Pred: size > 0
    // Post: output = size' = size − 1
    @Override
    public Object dequeue() {
        if (isEmpty()) {
            throw new IllegalStateException("Очередь пустая.");
        }
        Object item = head.value;
        head = head.next;
        if (head == null) {
            tail = null;
        }
        size--;
        return item;
    }

    // Post: output = size
    @Override
    public int size() {
        return size;
    }

    // Post: output = size > 0
    @Override
    public boolean isEmpty() {
        return size == 0;
    }

    @Override
    public void clear() {
        head = null;
        tail = null;
        size = 0;
    }
}
