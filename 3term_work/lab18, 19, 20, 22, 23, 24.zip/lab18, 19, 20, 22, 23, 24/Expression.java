package ru.mirea.lab23;

public abstract class Expression {
    public abstract double evaluate(double x);
}
