package ru.mirea.lab23;

import java.util.Objects;

public class ArrayQueue {
    private int size = 0;
    private final Object[] elements = new Object[10];
    private int head = 0;
    private int tail = 0;

    /* Инвариант:
    size >= 0;
    element != null */

    // Pred: element != null
    // Post: size' = size + 1 & elements'[size'] = element
    public void enqueue(Object element) {
        Objects.requireNonNull(element);
        if (size == elements.length) {
            throw new IllegalStateException("Очередь полная.");
        }
        elements[tail] = element;
        tail = (tail + 1) % elements.length;
        size++;
    }

    // Pred: size > 0
    // Post: output = elements[size'] & size' = size − 1
    public Object dequeue() {
        if (isEmpty()) {
            throw new IllegalStateException("Очередь пустая.");
        }
        Object item = elements[head];
        head = (head + 1) % elements.length;
        size--;
        return item;
    }

    // Pred: size > 0
    // Post: output = elements[size]
    public Object element() {
        if (isEmpty()) {
            throw new IllegalStateException("Очередь пустая.");
        }
        return elements[head];
    }

    // Post: output = size
    public int size() {
        return size;
    }

    // Post: output = size > 0
    public boolean isEmpty() {
        return size == 0;
    }

    public void clear() {
        head = 0;
        tail = 0;
        size = 0;
    }
}
