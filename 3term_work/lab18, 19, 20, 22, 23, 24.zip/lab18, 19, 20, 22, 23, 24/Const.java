package ru.mirea.lab23;

public class Const extends Expression {
    private final double val;

    public Const(double val) {
        this.val = val;
    }

    @Override
    public double evaluate(double x) {
        return val;
    }
}
