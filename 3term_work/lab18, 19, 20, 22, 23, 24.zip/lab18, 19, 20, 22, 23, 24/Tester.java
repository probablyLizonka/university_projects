package ru.mirea.lab23;


import java.util.InputMismatchException;
import java.util.Scanner;

public class Tester {
    public static void main(String[] args) {
        System.out.println("Для ArrayQueueModule с размером 10:");
        System.out.println("Проверяем пустая ли очередь: " + ArrayQueueModule.isEmpty());
        try {
            System.out.println("""
                    Заполняем очередь десятью элементами, на 11 выходит исключение.\
                    
                    Если элемент null, то выходит исключение.\
                    
                    Каждый раз возвращаем размер""");
            for (int i = 0; i < 11; i++) {
                ArrayQueueModule.enqueue(i);
                System.out.println("размер - " + ArrayQueueModule.size());
            }
        } catch (IllegalStateException | NullPointerException e) {
            System.out.println(e.getMessage());
        }
        System.out.println("Проверяем пустая ли очередь: " + ArrayQueueModule.isEmpty());
        System.out.println("Выводим первый элемент: " + ArrayQueueModule.element());
        System.out.println("Удаляем пять элементов и каждый раз возвращаем размер и элемент.");
        for (int i = 0; i < 5; i++) {
            System.out.println("размер - " + ArrayQueueModule.size() + ", элемент - " + ArrayQueueModule.dequeue());
        }
        System.out.println("Очищаем очередь.");
        ArrayQueueModule.clear();
        System.out.println("Проверяем пустая ли очередь: " + ArrayQueueModule.isEmpty());
        System.out.println("размер - " + ArrayQueueModule.size());
        try {
            System.out.println("Пытаемся вывести первый элемент и ловим исключение.");
            ArrayQueueModule.element();
        } catch (IllegalStateException e) {
            System.out.println(e.getMessage());
        }

        System.out.println("\nДля ArrayQueueADT с размером 10:");
        ArrayQueueADT queue = ArrayQueueADT.create();
        System.out.println("Проверяем пустая ли очередь: " + ArrayQueueADT.isEmpty(queue));
        try {
            System.out.println("""
                    Заполняем очередь десятью элементами, на 11 выходит исключение.\
                    
                    Если элемент null, то выходит исключение.\
                    
                    Каждый раз возвращаем размер""");
            for (int i = 0; i < 11; i++) {
                ArrayQueueADT.enqueue(queue, i);
                System.out.println("размер - " + ArrayQueueADT.size(queue));
            }
        } catch (IllegalStateException | NullPointerException e) {
            System.out.println(e.getMessage());
        }
        System.out.println("Проверяем пустая ли очередь: " + ArrayQueueADT.isEmpty(queue));
        System.out.println("Выводим первый элемент: " + ArrayQueueADT.element(queue));
        System.out.println("Удаляем пять элементов и каждый раз возвращаем размер и элемент.");
        for (int i = 0; i < 5; i++) {
            System.out.println("размер - " + ArrayQueueADT.size(queue) + ", элемент - " + ArrayQueueADT.dequeue(queue));
        }
        System.out.println("Очищаем очередь.");
        ArrayQueueADT.clear(queue);
        System.out.println("Проверяем пустая ли очередь: " + ArrayQueueADT.isEmpty(queue));
        System.out.println("размер - " + ArrayQueueADT.size(queue));
        try {
            System.out.println("Пытаемся вывести первый элемент и ловим исключение.");
            ArrayQueueADT.element(queue);
        } catch (IllegalStateException e) {
            System.out.println(e.getMessage());
        }

        System.out.println("\nДля ArrayQueue с размером 10:");
        ArrayQueue queue1 = new ArrayQueue();
        System.out.println("Проверяем пустая ли очередь: " + queue1.isEmpty());
        try {
            System.out.println("""
                    Заполняем очередь десятью элементами, на 11 выходит исключение.\
                    
                    Если элемент null, то выходит исключение.\
                    
                    Каждый раз возвращаем размер""");
            for (int i = 0; i < 11; i++) {
                queue1.enqueue(i);
                System.out.println("размер - " + queue1.size());
            }
        } catch (IllegalStateException | NullPointerException e) {
            System.out.println(e.getMessage());
        }
        System.out.println("Проверяем пустая ли очередь: " + queue1.isEmpty());
        System.out.println("Выводим первый элемент: " + queue1.element());
        System.out.println("Удаляем пять элементов и каждый раз возвращаем размер и элемент.");
        for (int i = 0; i < 5; i++) {
            System.out.println("размер - " + queue1.size() + ", элемент - " + queue1.dequeue());
        }
        System.out.println("Очищаем очередь.");
        queue1.clear();
        System.out.println("Проверяем пустая ли очередь: " + queue1.isEmpty());
        System.out.println("размер - " + queue1.size());
        try {
            System.out.println("Пытаемся вывести первый элемент и ловим исключение.");
            queue1.element();
        } catch (IllegalStateException e) {
            System.out.println(e.getMessage());
        }

        System.out.println("\nДля LinkedQueue:");
        LinkedQueue queue2 = new LinkedQueue();
        System.out.println("Проверяем пустая ли очередь: " + queue2.isEmpty());
        try {
            System.out.println("""
                    Заполняем очередь десятью элементами.\
                    
                    Если элемент null, то выходит исключение.\
                    
                    Каждый раз возвращаем размер""");
            for (int i = 0; i < 11; i++) {
                queue2.enqueue(i);
                System.out.println("размер - " + queue2.size());
            }
        } catch (IllegalStateException | NullPointerException e) {
            System.out.println(e.getMessage());
        }
        System.out.println("Проверяем пустая ли очередь: " + queue2.isEmpty());
        System.out.println("Выводим первый элемент: " + queue2.element());
        System.out.println("Удаляем пять элементов и каждый раз возвращаем размер и элемент.");
        for (int i = 0; i < 5; i++) {
            System.out.println("размер - " + queue2.size() + ", элемент - " + queue2.dequeue());
        }
        System.out.println("Очищаем очередь.");
        queue2.clear();
        System.out.println("Проверяем пустая ли очередь: " + queue2.isEmpty());
        System.out.println("размер - " + queue2.size());
        try {
            System.out.println("Пытаемся вывести первый элемент и ловим исключение.");
            queue2.element();
        } catch (IllegalStateException e) {
            System.out.println(e.getMessage());
        }

        System.out.println("Задание 3");
        System.out.println("Проверка выражения: 2 * х - 3");
        System.out.println("х = 5");
        System.out.println("Ответ: " + new Subtract(new Multiply(new Const(2), new Variable("x")),
                new Const(3)).evaluate(5));

        System.out.println("Проверка выражения: х^2 - 2 * х + 1 c пользовательским вводом.");
        System.out.print("Введите х: ");
        Scanner sc = new Scanner(System.in);
        double x;
        while (true) {
            try {
                x = sc.nextDouble();
                break;
            } catch (InputMismatchException e) {
                System.out.println("Введите х заново:");
                sc.nextLine();
            }
        }
        System.out.println("Ответ: " + new Add(new Subtract(new Multiply(new Variable("x"),
                new Variable("x")), new Multiply(new Const(2), new Variable("x"))),
                new Const(1)).evaluate(x));
    }
}
