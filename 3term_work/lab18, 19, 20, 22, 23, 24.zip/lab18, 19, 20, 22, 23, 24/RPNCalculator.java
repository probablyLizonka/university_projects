package ru.mirea.lab22;

public class RPNCalculator {
    public static void main(String[] args) {
        RPNCalculatorModel model = new RPNCalculatorModel();
        RPNCalculatorController controller = new RPNCalculatorController(model);
        new RPNCalculatorView(controller);
    }
}
