package ru.mirea.lab20;

import java.io.Serializable;

public class Test <T extends Comparable<T>, V extends Animal & Serializable, K>{
    private final T type;
    private final V value;
    private final K key;

    public Test(K key, T type, V value) {
        this.key = key;
        this.type = type;
        this.value = value;
    }

    public K getKey() {
        return key;
    }

    public T getType() {
        return type;
    }

    public V getValue() {
        return value;
    }

    public void printClassNames() {
        System.out.println("Class of T: " + type.getClass().getName());
        System.out.println("Class of V: " + value.getClass().getName());
        System.out.println("Class of K: " + key.getClass().getName());
    }
}

class Animal {}
