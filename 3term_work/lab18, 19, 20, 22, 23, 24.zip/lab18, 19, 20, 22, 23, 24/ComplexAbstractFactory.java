package ru.mirea.lab24;

interface ComplexAbstractFactory {
    Complex createComplex();

    Complex createComplex(int real, int imag);
}

class Complex {
    private int real;
    private int imag;

    public Complex() {
        this.real = 0;
        this.imag = 0;
    }

    public Complex(int imag, int real) {
        this.real = real;
        this.imag = imag;
    }

    @Override
    public String toString() {
        return "Комплексное число: " + real + " + " + imag + "i";
    }
}

class ConcreteFactory implements ComplexAbstractFactory{
    @Override
    public Complex createComplex(int real, int imag) {
        return new Complex(real, imag);
    }

    @Override
    public Complex createComplex() {
        return new Complex();
    }
}
