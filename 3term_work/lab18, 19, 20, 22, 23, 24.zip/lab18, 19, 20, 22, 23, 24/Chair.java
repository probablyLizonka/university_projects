package ru.mirea.lab24;

import java.util.InputMismatchException;
import java.util.Scanner;

interface Chair {
    void sit();
}


class VictorianChair implements Chair {
    private final int age;

    public int getAge() {
        return age;
    }

    public VictorianChair() throws InputMismatchException {
        System.out.println("Стул с каким возрастом вы хотите?");
        Scanner sc = new Scanner(System.in);
        age = sc.nextInt();
    }

    @Override
    public void sit() {
        System.out.println("Вы сидите на Викторианском стуле! Его возраст: " + getAge());
    }
}

class MagicalChair implements Chair {
    @Override
    public void sit() {
        System.out.println("Вы сидите на магическом стуле!");
        doMagic();
    }

    public void doMagic() {
        System.out.println("Магия произошла!");
    }
}


class FunctionalChair implements Chair {
    private final int summa;

    public FunctionalChair() throws InputMismatchException {
        System.out.println("Этот стул может посчитать сумму двух целых чисел.");
        Scanner sc = new Scanner(System.in);
        System.out.print("Введите первое число: ");
        int a = sc.nextInt();
        System.out.print("Введите второе число: ");
        int b = sc.nextInt();
        summa = sum(a, b);
    }

    @Override
    public void sit() {
        System.out.println("Вы сидите на стуле функций! Он нашел сумму: " + summa);
    }

    public int sum(int a, int b) {
        return a + b;
    }
}


interface AbstractChairFactory {
    VictorianChair createVictorianChair();

    MagicalChair createMagicChair();

    FunctionalChair createFunctionalChair();
}

class ChairFactory implements AbstractChairFactory {
    @Override
    public FunctionalChair createFunctionalChair() {
        return new FunctionalChair();
    }

    @Override
    public VictorianChair createVictorianChair() {
        return new VictorianChair();
    }

    @Override
    public MagicalChair createMagicChair() {
        return new MagicalChair();
    }
}

class Client {
    public Chair chair;

    public void setChair(Chair chair) {
        this.chair = chair;
    }

    public void sit() {
        chair.sit();
    }
}