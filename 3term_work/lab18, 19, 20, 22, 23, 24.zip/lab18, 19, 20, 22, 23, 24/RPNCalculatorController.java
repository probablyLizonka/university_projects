package ru.mirea.lab22;


public class RPNCalculatorController {
    RPNCalculatorModel model;

    public RPNCalculatorController(RPNCalculatorModel model) {
        this.model = model;
    }

    public void processExpression(String expression) {
        String[] tokens = expression.split(" ");
        for (String token : tokens) {
            if (token.matches("-?\\d+(\\.\\d+)?")) {
                model.push(Double.parseDouble(token));
            } else if ("+-*/".contains(token)) {
                model.calculate(token);
            } else {
                return;
            }
        }
    }


    public String getResult() {
        return model.getResult();
    }

    public void clear() {
        model.clear();
    }


}
