package ru.mirea.lab20;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Calculator {
    public Calculator() {
        Scanner sc = new Scanner(System.in);
        boolean running = true;
        while (running) {
            try {
                System.out.print("Введите первое число: ");
                if (!sc.hasNextDouble()) {
                    throw new InputMismatchException("Неверный ввод.");
                }
                double num1 = sc.nextDouble();
                sc.nextLine();
                System.out.print("Введите второе число: ");
                if (!sc.hasNextDouble()) {
                    throw new InputMismatchException("Неверный ввод.");
                }
                double num2 = sc.nextDouble();
                sc.nextLine();
                System.out.println("Сложение: " + sum(num1, num2));
                System.out.println("Вычитание: " + subtraction(num1, num2));
                System.out.println("Умножение: " + multiply(num1, num2));
                System.out.println("Деление: " + divide(num1, num2));
                running = false;
            } catch (InputMismatchException e) {
                System.out.println(e.getMessage());
                sc.nextLine();
            }
        }
    }

    public static <T extends Number, T1 extends Number> double sum(T num1, T1 num2) {
        return num1.doubleValue() + num2.doubleValue();
    }

    public static <T extends Number, T1 extends Number> double multiply(T num1, T1 num2) {
        return num1.doubleValue() * num2.doubleValue();
    }

    public static <T extends Number, T1 extends Number> double divide(T num1, T1 num2) {
        try {
            return num1.doubleValue() / num2.doubleValue();
        } catch (ArithmeticException e) {
            System.out.println(e.getMessage());
        }
        return 0;
    }

    public static <T extends Number, T1 extends Number> double subtraction(T num1, T1 num2) {
        return num1.doubleValue() - num2.doubleValue();
    }

    public static void main(String[] args) {
        new Calculator();
    }
}
