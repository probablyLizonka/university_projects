package ru.mirea.lab23;

public abstract class AbstractQueue implements Queue {
    private int size = 0;

    @Override
    public boolean isEmpty() {
        return size == 0;
    }

    @Override
    public void clear() {
        size = 0;
    }
}
