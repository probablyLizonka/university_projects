package ru.mirea.lab20;


public class MinMax<T extends Comparable<T>> {
    private final T[] array;

    public MinMax(T[] array) {
        this.array = array;
    }

    public String getClassOfType() {
        return array.getClass().getName();
    }

    public T getMin() {
        T mini = array[0];
        for (int i = 1; i < size(); i++) {
            if (mini.compareTo(array[i]) > 0) {
                mini = array[i];
            }
        }
        return mini;
    }

    public T getMax() {
        T maxi = array[0];
        for (int i = 1; i < size(); i++) {
            if (maxi.compareTo(array[i]) < 0) {
                maxi = array[i];
            }
        }
        return maxi;
    }

    public T[] getArray() {
        return array;
    }

    public int size() {
        return array.length;
    }

    public static void main(String[] args) {
        Integer[] d = {1, 2, 9, 10, 45, -54};
        MinMax<Integer> minMax1 = new MinMax<>(d);
        for (int i = 0; i < minMax1.size(); i++) {
            if (i == minMax1.size() - 1) {
                System.out.println(minMax1.getArray()[i]);
                continue;
            }
            System.out.print(minMax1.getArray()[i] + ", ");
        }
        System.out.println("min " + minMax1.getMin());
        System.out.println("max " + minMax1.getMax());

        System.out.println("----------");

        String[] s = {"asas", "adss", "d", "dsfd"};
        MinMax<String> minMax2 = new MinMax<>(s);
        for (int i = 0; i < minMax2.size(); i++) {
            if (i == minMax2.size() - 1) {
                System.out.println(minMax2.getArray()[i]);
                continue;
            }
            System.out.print(minMax2.getArray()[i] + ", ");
        }
        System.out.println("min " + minMax2.getMin());
        System.out.println("max " + minMax2.getMax());

        System.out.println("----------");

        Double[] lf = {12.5, 34.0, 0.0, -56.7};
        MinMax<Double> minMax3 = new MinMax<>(lf);
        for (int i = 0; i < minMax3.size(); i++) {
            if (i == minMax3.size() - 1) {
                System.out.println(minMax3.getArray()[i]);
                continue;
            }
            System.out.print(minMax3.getArray()[i] + ", ");
        }
        System.out.println("min " + minMax3.getMin());
        System.out.println("max " + minMax3.getMax());
    }
}

