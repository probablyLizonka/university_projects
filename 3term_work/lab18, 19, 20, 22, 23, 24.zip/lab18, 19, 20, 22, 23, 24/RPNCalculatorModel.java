package ru.mirea.lab22;

import java.util.Stack;

public class RPNCalculatorModel {
    private final Stack<Double> stack = new Stack<>();

    public void push(double value) {
        stack.push(value);
    }

    public void calculate(String operator){
        if (stack.size() < 2) {
            System.out.println("Недостаточно чисел для выполнения операции.");
            return;
        }
        double b = stack.pop();
        double a = stack.pop();
        switch (operator) {
            case "+":
                stack.push(a + b);
                break;
            case "-":
                stack.push(a - b);
                break;
            case "*":
                stack.push(a * b);
                break;
            case "/":
                if (b == 0) {
                    System.out.println("Деление на ноль запрещено.");
                    return;
                }
                stack.push(a / b);
                break;
            default:
               System.out.println("Неверный опратор.");
        }
    }

    public String getResult() {
        return stack.isEmpty() ? "0" : stack.peek().toString();
    }

    public void clear() {
        stack.clear();
    }
}
