package ru.mirea.lab18;

import java.util.Objects;
import java.util.Scanner;

class Exception1 {
    public void exceptionDemo() {
        System.out.println(2.0 / 0.0);

        try {
            System.out.println(2 / 0);
        } catch (ArithmeticException e) {
            System.out.println("Attempted division by zero");
        }
    }
}

class Exception2 {
    public void exceptionDemo() {
        try {
            Scanner myScanner = new Scanner(System.in);
            System.out.print("Enter an integer ");
            String intString = myScanner.next();
            int i = Integer.parseInt(intString);
            System.out.println(2 / i);
        } catch (NumberFormatException | ArithmeticException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception " + e.getClass().getSimpleName() + " was processed. Program continues.");
        } finally {
            System.out.println("finally block");
        }
    }
}

class ThrowsDemo {
    public void printMessage(String key) {
        String message = getDetails(key);
        System.out.println(message);
    }

    public String getDetails(String key) {
        try {
            if (key == null) {
                throw new NullPointerException("null key in getDetails");
            }
        } catch (NullPointerException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception " + e.getClass().getSimpleName() + " was processed. Program continues.");
        }
        return "data for " + key;
    }
}

class ThrowsDemo1 {
    public void getKey() throws Exception {
        Scanner myScanner = new Scanner(System.in);
        String key = myScanner.next();
        printDetails(key);
    }

    public void printDetails(String key) throws Exception {
        String message = getDetails(key);
        System.out.println(message);
    }

    private String getDetails(String key) throws Exception {
        if (Objects.equals(key, "")) {
            throw new Exception("Key set to empty string");
        }
        return "data for " + key;
    }
}


public class Test {
    public static void main(String[] args) throws Exception {
        Exception1 exception1 = new Exception1();
        exception1.exceptionDemo();
        System.out.println("-----------------");
        Exception2 exception2 = new Exception2();
        exception2.exceptionDemo();
        System.out.println("-----------------");
        ThrowsDemo throwsDemo = new ThrowsDemo();
        throwsDemo.getDetails(null);
        throwsDemo.printMessage(null);
        throwsDemo.printMessage("s");
        System.out.println("-----------------");
        ThrowsDemo1 throwsDemo1 = new ThrowsDemo1();
        throwsDemo1.getKey();
    }
}
