package ru.mirea.lab22;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class RPNCalculatorView extends JFrame implements ActionListener {
    JTextField window1, window;
    private RPNCalculatorController controller;

    private StringBuilder currentExpression = new StringBuilder();
    private boolean lastInputWasOperator = false;
    private boolean lastInputWasDot = false;


    public RPNCalculatorView(RPNCalculatorController controller) {
        super("Польский калькулятор");
        setSize(515, 450);

        this.controller = controller;

        Font fnt = new Font("Times new roman", Font.BOLD, 20);

        JButton addButton = new JButton("+");
        JButton subButton = new JButton("-");
        JButton mulButton = new JButton("*");
        JButton divButton = new JButton("/");
        JButton resButton = new JButton("=");
        JButton dotButton = new JButton(".");
        JButton clearButton = new JButton("C");
        JButton fButton = new JButton(" ");
        JButton[] actionButtons = new JButton[8];
        JButton[] numberButtons = new JButton[10];
        for (int i = 0; i < 10; i++) {
            numberButtons[i] = new JButton(String.valueOf(i));
            numberButtons[i].setFont(fnt);
            numberButtons[i].setBackground(Color.WHITE);
            numberButtons[i].addActionListener(this);
        }

        actionButtons[0] = addButton;
        actionButtons[1] = subButton;
        actionButtons[2] = mulButton;
        actionButtons[3] = divButton;
        actionButtons[4] = resButton;
        actionButtons[5] = dotButton;
        actionButtons[6] = clearButton;
        actionButtons[7] = fButton;
        for (int i = 0; i < 8; i++) {
            actionButtons[i].setFont(fnt);
            actionButtons[i].setBackground(Color.WHITE);
            actionButtons[i].addActionListener(this);
        }

        JPanel buttons = new JPanel();
        buttons.setBounds(25, 200, 450, 200);
        buttons.setLayout(new GridLayout(4, 4, 10, 10));
        buttons.add(numberButtons[7]);
        buttons.add(numberButtons[8]);
        buttons.add(numberButtons[9]);
        buttons.add(actionButtons[3]);
        buttons.add(numberButtons[4]);
        buttons.add(numberButtons[5]);
        buttons.add(numberButtons[6]);
        buttons.add(actionButtons[2]);
        buttons.add(numberButtons[3]);
        buttons.add(numberButtons[2]);
        buttons.add(numberButtons[1]);
        buttons.add(actionButtons[1]);
        buttons.add(numberButtons[0]);
        buttons.add(actionButtons[5]);
        buttons.add(actionButtons[4]);
        buttons.add(actionButtons[0]);

        actionButtons[6].setBounds(25, 15, 50, 50);
        actionButtons[7].setBounds(25, 75, 50, 50);

        window1 = new JTextField("");
        window1.setBounds(85, 15, 390, 110);
        window1.setBackground(Color.WHITE);
        window1.setEditable(false);
        window1.setHorizontalAlignment(SwingConstants.RIGHT);
        window1.setFont(fnt);
        window1.setFocusable(false);

        window = new JTextField("");
        window.setBounds(25, 135, 450, 50);
        window.setBackground(Color.WHITE);
        window.setEditable(false);
        window.setHorizontalAlignment(SwingConstants.RIGHT);
        window.setFont(fnt);
        window.setFocusable(false);


        add(actionButtons[6]);
        add(actionButtons[7]);
        add(window1);
        add(window);
        add(buttons);

        setLayout(null);
        setVisible(true);
        setResizable(false);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String command = ((JButton) e.getSource()).getText();

        try {
            if (command.equals("=")) {
                controller.processExpression(currentExpression.toString().trim());
                window.setText(controller.getResult());
                window1.setText(currentExpression.toString() + " =");
                currentExpression.setLength(0);
                currentExpression.append(controller.getResult());
                lastInputWasOperator = false;
                lastInputWasDot = false;
            } else if (command.equals(" ")){
                currentExpression.append(command);
                window.setText(currentExpression.toString());
                lastInputWasOperator = false;
                lastInputWasDot = false;
            } else if (command.equals("C")) {
                controller.clear();
                currentExpression.setLength(0);
                window.setText("0");
                lastInputWasOperator = false;
                lastInputWasDot = false;
            } else if ("+-*/".contains(command)) {
                if (lastInputWasOperator) {
                    return;
                }
                currentExpression.append(command);
                window.setText(currentExpression.toString());
                lastInputWasOperator = true;
                lastInputWasDot = false;
            } else if (command.equals(".")) {
                if (lastInputWasDot) {
                    return;
                }
                currentExpression.append(command);
                window.setText(currentExpression.toString());
                lastInputWasDot = true;
                lastInputWasOperator = false;
            } else {
                currentExpression.append(command);
                window.setText(currentExpression.toString());
                lastInputWasOperator = false;
                lastInputWasDot = false;
            }
        } catch (Exception ex) {
            window.setText("Ошибка");
            System.out.println(ex.getMessage());
            currentExpression.setLength(0);
            controller.clear();
            lastInputWasOperator = false;
            lastInputWasDot = false;
        }
    }
}


