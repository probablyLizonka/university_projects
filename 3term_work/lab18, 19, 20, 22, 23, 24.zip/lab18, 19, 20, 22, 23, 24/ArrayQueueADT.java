package ru.mirea.lab23;

import java.util.Objects;

public class ArrayQueueADT {
    private static int size = 0;
    private static Object[] elements = new Object[5];
    private static int head = 0;
    private static int tail = 0;

    /* Инвариант:
    size >= 0;
    element != null */

    public static ArrayQueueADT create() {
        ArrayQueueADT queue = new ArrayQueueADT();
        queue.elements = new Object[10];
        return queue;
    }

    // Pred: element != null
    // Post: size' = size + 1 & elements'[size'] = element
    public static void enqueue(ArrayQueueADT queue, Object element) {
        Objects.requireNonNull(element);
        if (queue.size == queue.elements.length) {
            throw new IllegalStateException("Очередь полная.");
        }
        queue.elements[queue.tail] = element;
        queue.tail = (queue.tail + 1) % queue.elements.length;
        queue.size++;
    }

    // Pred: size > 0
    // Post: output = elements[size'] & size' = size − 1
    public static Object dequeue(ArrayQueueADT queue) {
        if (isEmpty(queue)) {
            throw new IllegalStateException("Очередь пустая.");
        }
        Object item = queue.elements[queue.head];
        queue.head = (queue.head + 1) % queue.elements.length;
        queue.size--;
        return item;
    }

    // Pred: size > 0
    // Post: output = elements[size]
    public static Object element(ArrayQueueADT queue) {
        if (isEmpty(queue)) {
            throw new IllegalStateException("Очередь пустая.");
        }
        return queue.elements[queue.head];
    }

    // Post: output = size
    public static int size(ArrayQueueADT queue) {
        return queue.size;
    }

    // Post: output = size > 0
    public static boolean isEmpty(ArrayQueueADT queue) {
        return queue.size == 0;
    }

    public static void clear(ArrayQueueADT queue) {
        queue.head = 0;
        queue.tail = 0;
        queue.size = 0;
    }
}
