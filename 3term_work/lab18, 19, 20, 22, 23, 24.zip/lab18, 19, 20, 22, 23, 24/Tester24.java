package ru.mirea.lab24;

import java.util.InputMismatchException;
import java.util.Scanner;

class Tester {
    public static Client needChair() {
        Scanner sc = new Scanner(System.in);
        Client client = new Client();
        AbstractChairFactory chairFactory = new ChairFactory();
        int choose;
        while (true) {
            try {
                System.out.println("""
                Выберете желаемый стул:\
                
                1. Викторианский\
                
                2. Магический\
                
                3. Функциональный\
                """);
                 choose = sc.nextInt();
                switch (choose) {
                    case 1 -> client.setChair(chairFactory.createVictorianChair());
                    case 2 -> client.setChair(chairFactory.createMagicChair());
                    case 3 -> client.setChair(chairFactory.createFunctionalChair());
                }
                break;
            } catch (InputMismatchException e) {
                System.out.println("Неверный ввод.");
                sc.nextLine();
            }
        }
        return client;
    }

    public static void main(String[] args) {
        System.out.println("Задание 1");
        ComplexAbstractFactory factory = new ConcreteFactory();
        Complex defaultComplex = factory.createComplex();
        System.out.println("По умолчанию: " + defaultComplex);
        Complex paramComplex = factory.createComplex(3, 4);
        System.out.println("С заданием параметров: " + paramComplex);

        System.out.println("Задание 2");
        Client client = needChair();
        client.sit();
    }
}
