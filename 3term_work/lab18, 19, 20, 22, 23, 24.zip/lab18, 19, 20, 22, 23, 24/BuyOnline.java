package ru.mirea.lab19;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

class BuyOnline {
    Scanner sc = new Scanner(System.in);
    private String name;
    private final Map<String, String> dataBase = new HashMap<>();


    public void setInn() throws INNException {
        String inn = sc.nextLine();
        if (!(dataBase.get(name).equals(inn))) {
            throw new INNException("ИНН не действителен.");
        } else {
            System.out.println("ИНН действителен.");
        }
    }


    public void setName() {
        name = sc.nextLine();
        while (!dataBase.containsKey(name)) {
            System.out.print("Введеного имени нет в базе. Введите снова: ");
            name = sc.nextLine();
        }
    }


    public BuyOnline() {
        dataBase.put("Супрунова Е.В.", "123456789876");
        dataBase.put("Комлева М.С.", "565656565656");

        System.out.print("Введите ФИО в формате 'Фамилия И.О.:' ");
        setName();
        System.out.print("Введите ИНН: ");
        try {
            setInn();
            System.out.println("Приятных покупок!");
        }
        catch (INNException e) {
            System.out.println(e.getMessage());
            System.out.println("Исключение " + e.getClass().getSimpleName() + " обработано.");
        }
        finally {
            System.out.println("Программа завершена.");
        }
    }

    public static void main(String[] args) {
        new BuyOnline();
    }
}

class INNException extends Exception {
    public INNException(String message) {
        super(message);
    }
}
